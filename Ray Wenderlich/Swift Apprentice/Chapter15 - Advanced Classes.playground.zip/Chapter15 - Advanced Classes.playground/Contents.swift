import Cocoa

// Introducing inheritance

class Person {
    var firstName : String
    var lastName: String
    
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
    }
}
struct Grade {
    let letter: String
    let points: Double
    let credits: Double
}
//class Student: Person {
//    var grades: [Grade] = []
//    
//    func recordGrade(_ grade: Grade) {
//        grades.append(grade)
//    }
//}

//class BandMember: Student {
//    var minimumPracticeTime = 2
//}
//
//class OboePlayer: BandMember {
//    override var minimumPracticeTime: Int {
//        get {
//            return super.minimumPracticeTime * 2
//        }
//        set {
//            super.minimumPracticeTime = newValue / 2
//        }
//    }
//}
//
//func phoneBookName(_ person: Person) -> String {
//    return "\(person.lastName), \(person.firstName)"
//}
//
//let person = Person(firstName: "Johnny", lastName: "Appleseed")
//let oboePlayer = OboePlayer(firstName: "Jane", lastName: "Appleseed")
//
//phoneBookName(person)
//phoneBookName(oboePlayer)
//
//var hallMonitor = Student(firstName: "Jill", lastName: "Bananapeel")
//
//if let hallMonitor = hallMonitor as? BandMember {
//    print("This hall monitor is a band member and practices at least \(hallMonitor.minimumPracticeTime) hours per week")
//}

// Inheritance and class initialisation

class StudentAthlete1: Student1 {
    var failedClasses: [Grade] = []
    var sports: [String]
    
    required init(firstName: String, lastName: String) {
        self.sports = []
        super.init(firstName: firstName, lastName: lastName)
    }
    
    init(firstName: String, lastName: String, sports: [String]) {
        self.sports = sports
        let passGrade = Grade(letter: "P", points: 0.0, credits: 0.0)
        super.init(firstName: firstName, lastName: lastName)
        recordGrade(passGrade)
    }
    
    override func recordGrade(_ grade: Grade) {
        super.recordGrade(grade)
        if grade.letter == "F" {
            failedClasses.append(grade)
        }
    }
    var isEligible: Bool {
        return failedClasses.count < 3
    }
}

/* Mini-exercise page 223
 What’s different in the two-phase initialization in the base class Person, as compared to the others?
 Answer: Person is the superclass, no need to call super.init(...)
 */
class Student1 {
    let firstName: String
    let lastName: String
    var grades: [Grade] = []
    
    required init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
    }
    
    convenience init(transfer: Student1) {
        self.init(firstName: transfer.firstName, lastName: transfer.lastName)
    }
    
    convenience init(with fullName: String){
        var fullNameArr = fullName.components(separatedBy: " ")
        self.init(firstName: fullNameArr[0], lastName: fullNameArr[1])
    }
    convenience init() {
        self.init(firstName: "", lastName: "")
    }
    
    func recordGrade(_ grade: Grade) {
        grades.append(grade)
    }
    
    static var graduates: [String] = []
    deinit {
        Student1.graduates.append("\(firstName) \(lastName)")
    }
    
}

/* Mini exercise page 225 - Required and convenience initializers
    Create two more convenience initializers on Student. What other initializers are you able to call?
 Answer: See tha init(with fullName:), init() above (lines 105-111). All initializers are available
 */

// When and why to subclass

class Team {
    var players: [StudentAthlete1] = []
    
    var isEligible: Bool {
        for player in players {
            if !player.isEligible {
                return false
            }
        }
        return true
    }
}


/* Mini exercise page 229 - deinitialization 
 Modify the Student class to have the ability to record the student’s name to a list of graduates. 
 Add the name of the student to the list when the object is deallocated.
 Answer: See Student class above (lines 117-120)
 */

/* CHALLENGES page 231 */

/* 1. 
 Create three simple classes called A, B, and C where C inherits from B and B inherits from A. 
    In each class initializer, call print("I'm <X>!") both before and after super.init(). 
    Create an instance of C called c.  What order do you see each print() called in?
 */

// C - B - A - B - C 

/* 2. 
 Implement deinit for each class. Place your c inside of a do { } scope which will cause the 
    reference count to go to zero when it exits the scope. What order are the classes deinitialized in?
 */
// C - B - A

/* 3. 
 Cast the instance of type C to an instance of type A. Which casting operation do you use and why?
 */
print("Challenges 1,2,3: ")
class A {
    init() {
        print("I'm <A>!")
    }
    deinit {
        print("Removing A...")
    }
}
class B: A {
    override init() {
        print("I'm <B>!")
        super.init()
        print("I'm <B>!")
    }
    deinit {
        print("Removing B...")
    }
}
class C: B {
    override init() {
        print("I'm <C>!")
        super.init()
        print("I'm <C>!")
    }
    deinit {
        print("Removing C...")
    }
}
do {
    var c = C()
    let a = c as A
}

/* 4. 
 Create a subclass of StudentAthlete called StudentBaseballPlayer and include properties for position, 
    number, and battingAverage.  What are the benefits and drawbacks of subclassing StudentAthlete in this scenario?
 */
print("\nChallenge 4: ")

class Student: Person {
    var grades: [Grade] = []
}

class StudentAthlete: Student {
    var sports: [String] = []
}

class StudentBaseballPlayer: StudentAthlete {
    var position: String
    var number: Int
    var battingAverage: Double = 0.0
    
    init(firstName: String, lastName: String, number: Int, position: String) {
        self.number = number
        self.position = position
        super.init(firstName: firstName, lastName: lastName)
    }
}

/* 5. Can you think of an alternative to sublcassing? Assume you could modify any class in the hierarchy. */

/* 6. Fix the following classes so there isn't a memory leak when you add an order. */
print("\nChallenge 6: ")

class Customer {
    let name: String
    var orders: [Order] = []
    init(name: String) {
        self.name = name
    }
    func add(_ order: Order) {
        order.customer = self
        orders.append(order)
    }
    deinit {
       print("Removing \(name)...")
    }
}

class Order {
    let product: String
    weak var customer: Customer?
    init(product: String) {
        self.product = product
    }
    deinit {
        print("Removing \(product)...")
    }
 }
do {
    let customer = Customer(name: "Daniel")
    let order = Order(product: "Cheesecake")
    customer.add(order)
}



