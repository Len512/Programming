//: Playground - noun: a place where people can play

import Cocoa

/* Mini exercises page 115 - Introducing optionals 
 1. Make an optional String called myFavoriteSong. If you have a favorite song, set it to a string representing that song. If you have more than one favorite song or no favorite, set the optional to nil.
 2. Create a constant called parsedInt and set it equal to Int("10") which tries to parse the string 10 and convert it to an Int. Check the type of parsedInt using Option-Click. Why is it an optional?
 3. Change the string being parsed in the above exercise to a non-integer (try dog for example). What does parsedInt equal now?
 */
var myFavouriteSong: String? = nil
let parsedInt = Int("10")
// It is an optional because if the parsing cannot be done (the String might not contain an integer), the result will be nil
let parsedInt1 = Int("dog")

/* Mini exercises page 119 - Unwrapping optionals
 1. Using your myFavoriteSong variable from earlier, use optional binding to check if it contains a value. 
    If it does, print out the value. If it doesn’t, print "I don’t have a favorite song."
 2. Change myFavoriteSong to the opposite of what it is now. If it’s nil, set it to a string; 
    if it’s a string, set it to nil. Observe how your printed result changes.
*/

// myFavouriteSong = "With Strength I Burn"

if let myFavouriteSong = myFavouriteSong {
    print(myFavouriteSong)
} else {
    print("I don't have a favourite song.")
}

/* CHALLENGES page 122 */

/* A: You be the compiler
 Which of the following are valid statements?
 
 var name: String? = "Ray"
 var age: Int = nil
 let distance: Float = 26.7
 var middleName: String? = nil
*/
// yes, no, yes, yes
var name: String? = "Ray"
//var age: Int = nil
let distance: Float = 26.7
var middleName: String? = nil

/* B: Divide and conquer
 
 First, create a function that returns the number of times an integer can be divided by another integer 
    without a remainder. The function should return nil if the division doesn’t produce a whole number. 
    Name the function divideIfWhole.
 Then, write code that tries to unwrap the optional result of the function. There should be two cases:
    upon success, print "Yep, it divides \(answer) times", and upon failure, print "Not divisible :[".
 
 Finally, test your function:
 
 Divide 10 by 2. This should print "Yep, it divides 5 times."
 Divide 10 by 3. This should print "Not divisible :[."
 
 Hint 1: Use the following as the start of the function signature:
 
 func divideIfWhole(_ value: Int, by divisor: Int)
 
 You’ll need to add the return type, which will be an optional!
 
 Hint 2: You can use the modulo operator (%) to determine if a value is divisible by another; 
    recall that this operation returns the remainder from the division of two numbers. For example, 
    10 % 2 = 0 means that 10 is divisible by 2 with no remainder, whereas 10 % 3 = 1 means that 10 
    is divisible by 3 with a remainder of 1. */

func divideIfWhole(_ value: Int, by divisor: Int) -> Int? {
    return (value % divisor == 0) ? value / divisor : nil
}
if let res = divideIfWhole(10, by: 2) {
    print("Yep, it divides \(res) times.")
} else {
    print("Not divisible :[.")
}
if let res = divideIfWhole(10, by: 3) {
    print("Yep, it divides \(res) times.")
} else {
    print("Not divisible :[.")
}


/* C: Refactor and reduce
 
 The code you wrote in the last challenge used if statements. In this challenge, refactor that code 
    to use nil coalescing instead. This time, make it print "It divides X times" in all cases, but 
    if the division doesn’t result in a whole number, then X should be 0.  */

var res = divideIfWhole(10, by: 2) ?? 0
print("It divides \(res) times")
res = divideIfWhole(10, by: 3) ?? 0
print("It divides \(res) times")


/* D: Nested optionals
 
 Consider the following nested optional. It corresponds to a number inside a box inside a box inside a box.
 
 let number: Int??? = 10
 If you print number you get the following:
 
 print(number)
 // Optional(Optional(Optional(10)))
 
 print(number!)
 // Optional(Optional(10))
 
 1. Fully force unwrap and print number.
 2. Optionally bind and print number with if let.
 3. Write a function printNumber(_ number: Int???) that uses guard to print the number only if it is bound. */

let number: Int??? = 10
// 1
print("CASE 1:")
print(number)
print(number!)
print(number!!)
print(number!!!)
// 2
print("CASE 2a:")
if let num1 = number {
    if let num2 = num1 {
        if let num3 = num2 {
            print(num3)
        }
    }
}
print("CASE 2b:")
if let num1 = number, let num2 = num1, let num3 = num2 {
    print(num3)
}
print("CASE 3:")
func printNumber(_ number: Int???) {
    guard let num1 = number, let num2 = num1, let num3 = num2 else {
        return
    }
    print(num3)
}
printNumber(number)
printNumber(15)

