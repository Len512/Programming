import Cocoa

// Introducing structures

let restaurantLocation = (2, 4)
let restaurantRange = 2.5

let otherRestaurantLocation = (7, 8)
let otherRestaurantRange = 1.5

func distance(from source: (x: Int, y: Int), to target: (x: Int, y: Int)) -> Double {
    let distanceX = Double(source.x - target.x)
    let distanceY = Double(source.y - target.y)
    return sqrt(distanceX * distanceX + distanceY * distanceY)
}

func isInDeliveryRange(location: (x: Int, y: Int)) -> Bool {
    let deliveryDistance = distance(from: location, to: restaurantLocation)
    let secondDeliveryDistance = distance(from: location, to: otherRestaurantLocation)
    return deliveryDistance < restaurantRange || secondDeliveryDistance < otherRestaurantRange
}

struct Location {
    let x: Double
    let y: Double
}
let storeLocation = Location(x: 2, y: 4)

struct DeliveryArea1 {
    var range: Double
    let center: Location
}

var storeArea = DeliveryArea1(range: 4, center: storeLocation)

/* Mini exercise page 166 - Introducing structures 
    Write a struct that represents a pizza order. Include toppings, size and any other option you’d want for a pizza.
 */
struct Pizza {
    let toppings : [String]
    let crustType : String
    let size : String
    let cheezeInCrust: Bool
}
print(storeArea.range)
print(storeArea.center)
print(storeArea.center.x)
storeArea.range = 250

/* Mini exercise page 167 - Accessing members 
 Rewrite isInDeliveryRange to use Location and DeliveryArea.
 */
func distance(from source: Location, to target: Location) -> Double {
    let distanceX = source.x - target.x
    let distanceY = source.y - target.y
    return sqrt(distanceX * distanceX + distanceY * distanceY)
}
let areas = [
    DeliveryArea1(range: 2.5, center: Location(x: 2, y: 4)),
    DeliveryArea1(range: 4.5, center: Location(x: 9, y: 7))
]

func isInDeliveryRange(_ location: Location) -> Bool {
    for area in areas {
        let storeLocation = Location(x: area.center.x, y: area.center.y)
        let distanceToStore = distance(from: storeLocation, to: location)
        if distanceToStore < area.range {
            return true
        }
    }
    return false
}

let customerLocation1 = Location(x: 8, y: 1)
let customerLocation2 = Location(x: 5, y: 5)

print(isInDeliveryRange(customerLocation1))
print(isInDeliveryRange(customerLocation2))

struct DeliveryArea: CustomStringConvertible {
    var range: Double
    let center: Location
    
    func contains(_ location: Location) -> Bool {
        let distanceFromCenter = distance(from: center, to: location)
        return distanceFromCenter < range
    }
    func overlaps(with area: DeliveryArea) -> Bool {
        return distance(from: center, to: area.center) >= (range + area.range)
    }
    var description: String {
        return "Area with range: \(range), location (x,y): (\(center.x), \(center.y))"
    }
}
let area = DeliveryArea(range: 4.5, center: Location(x: 5, y: 5))
let customerLocation = Location(x: 2, y: 2)
area.contains(customerLocation)

/* Mini exercise page 168 - Introducing methods
 Add a method overlaps(with:) on DeliveryArea that can tell you
 if the area overlaps with another area. */

let area1 = DeliveryArea(range: 2.5, center: Location(x: 2, y: 4))
let area2 = DeliveryArea(range: 2.5, center: Location(x: 1, y: 11))
let area3 = DeliveryArea(range: 45, center: Location(x: 0, y: 0))
print(area1.overlaps(with: area2))
print(area1.overlaps(with: area3))

//public protocol CustomStringConvertible {
//    public var description: String { get }
//}
print(area1)
print(area2)
print(area3)

/* CHALLENGES page 171 */

/* 1. Tic-Tac-Toe 
 Implement a "playable" version of Tic-Tac-Toe (OXO). The focus of this exercise is on using structures. Represent Xs with a global string constant "X" and Os with a global string contant "O". While X and O could be cleanly represented with an enumeration type, you will learn about those in Chapter 16. For now, you can make the type called BoardPiece as an alias to String using typealias. The BoardPiece type can be used completely interchangably with a String. While this doesn't afford much in the way of formal type safety, it does add to the readability and documentation of your code.
 typealias BoardPiece = String
 let X: BoardPiece = "X"
 let O: BoardPiece = "O"
 */
typealias BoardPiece = String
let X: BoardPiece = "X"
let O: BoardPiece = "O"

struct Game {
    var board: [BoardPiece?] = [nil, nil, nil,
                                nil, nil, nil,
                                nil, nil, nil]
    var currentPlayer = O
    
    var winner: BoardPiece? {
        let winningCombinations = [[0, 1, 2], [0, 3, 6], [0, 4, 8], [1, 4, 7], [2, 5, 8], [3, 4, 5], [6, 7, 8], [2, 4, 6]]
        
        for combination in winningCombinations {
            let result = combination.map { board[$0]}
            if result.filter( {$0 == X} ).count == 3 {
                return X
            }
            if result.filter( {$0 == O} ).count == 3 {
                return O
            }
        }
        return nil
    }
    
    var isFinished: Bool {
        return winner != nil || !board.contains{ $0 == nil }
    }
    
    mutating func processSelection(position: Int) {
        if position < 0 || position >= board.count {
            return
        }
        if board[position] != nil {
            return
        }
        board[position] = currentPlayer
        currentPlayer = currentPlayer == X ? O : X
    }
    
    func printBoard() {
        print()
        print(" \(board[0] ?? " ") | \(board[1] ?? " ") | \(board[2] ?? " ") ")
        print("-----------")
        print(" \(board[3] ?? " ") | \(board[4] ?? " ") | \(board[5] ?? " ") ")
        print("-----------")
        print(" \(board[6] ?? " ") | \(board[7] ?? " ") | \(board[8] ?? " ") ")
        print()
        
    }
}


var game = Game()

print("Welcome to Tic-Tac-Toe")
game.printBoard()

game.processSelection(position: 4)
game.processSelection(position: 3)
game.processSelection(position: 5)
game.processSelection(position: 2)
game.processSelection(position: 8)
game.processSelection(position: 1)
game.processSelection(position: 0)
game.processSelection(position: 6)
game.printBoard()

print("Game over!")
if let winner = game.winner {
    print("The winner is player \(winner). Congratulations!")
} else {
    print("The game is tied. Try again!")
}


/* 2. Create a T-shirt struct that has size, color and material options. Provide methods to calculate the cost of a shirt based on its attributes */
typealias Size = String
let Small: Size = "Small"
let Medium: Size = "Medium"
let Large: Size = "Large"

typealias Material = String
let Cotton: Material = "Cotton"
let Wool: Material = "Wool"
let Polyester: Material = "Polyester"

typealias Colour = String

struct TShirt {
    let size: Size
    let material: Material
    let colour: Colour
    
    func cost() -> Double {
        var price = 15.0
        
        let sizeFactor: Double
        switch size {
        case Small:
            sizeFactor = 1.0
        case Medium:
            sizeFactor = 1.1
        case Large:
            sizeFactor = 1.2
        default:
            sizeFactor = 1.5
        }
        
        let materialFactor: Double
        switch material {
        case Cotton:
            materialFactor = 1.0
        case Polyester:
            materialFactor = 1.2
        case Wool:
            materialFactor = 1.5
        default:
            materialFactor = 1.8
        }
        price *= sizeFactor * materialFactor
        return price
    }
}

let smallCottonPrice = TShirt(size: Small, material: Cotton, colour: "Black").cost()
print("A black cotton t-shirt of size small costs \(smallCottonPrice) euro.")
let largeWoolPrice = TShirt(size: Large, material: Wool, colour: "Red").cost()
print("A red woollen t-shirt of size large costs \(largeWoolPrice) euro.")


/* 3. Write the engine for a Battleship-like game
 Use an (x,y) coordinate system for your locations and model using a structure
 Ships should also be modelled with structures. Record an origin, direction and length
 Each ship should be able to report if a "shot" has resulted in a "hit" or is off by 1
 */

struct Coordinate {
    let x: Int
    let y: Int
}

struct Ship {
    let origin: Coordinate
    let direction: String
    let length: Int
    
    func isHit(coordinate: Coordinate) -> Bool {
        if direction == "Horisontal" {
            return origin.y == coordinate.y && coordinate.x >= origin.x && coordinate.x - origin.x < length
        } else {
            return origin.x == coordinate.x && coordinate.y >= origin.y && coordinate.y - origin.y < length
        }
    }
    func isOff(coordinate: Coordinate) -> Bool {
        if direction == "Horisontal" {
            return (( coordinate.x >= origin.x && coordinate.x - origin.x < length )
                && ( origin.y == coordinate.y + 1 || origin.y == coordinate.y - 1))
                || ( origin.y == coordinate.y && ( origin.x == coordinate.x + 1 || origin.x == coordinate.x - length))
        } else {
            return (( coordinate.y >= origin.y && coordinate.y - origin.y < length )
                && ( origin.x == coordinate.x + 1 || origin.x == coordinate.x - 1 ))
                || ( origin.x == coordinate.x && ( origin.y == coordinate.y + 1 || origin.y == coordinate.y - length))
        }
    }
}

struct Board {
    var ships: [Ship] = []
    
    func shoot (location: Coordinate) -> Bool {
        for ship in ships {
            if ship.isHit(coordinate: location) {
                print("A ship was hit!")
                return true
            } else if ship.isOff(coordinate: location) {
                print("Off by 1!")
                return false
            }
        }
        return false
    }
}

let boat = Ship(origin: Coordinate(x: 1, y: 1), direction: "Horisontal", length: 2)
let battleship = Ship(origin: Coordinate(x: 4, y: 2), direction: "Vertical", length: 4)
let submarine = Ship(origin: Coordinate(x: 0, y: 0), direction: "Vertical", length: 3)

var board = Board()

board.ships.append(boat)
board.ships.append(battleship)
board.ships.append(submarine)

board.shoot(location: Coordinate(x: 1, y: 1))
board.shoot(location: Coordinate(x: 4, y: 4))
board.shoot(location: Coordinate(x: 6, y: 5))
board.shoot(location: Coordinate(x: 0, y: 3))