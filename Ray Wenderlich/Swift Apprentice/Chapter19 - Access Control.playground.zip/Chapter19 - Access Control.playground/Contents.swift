import Cocoa

// Problems introduced by lack of access control

//let account = BasicAccount()
//account.deposit(amount: 10.00)
//account.withdraw(amount: 5.00)
////account.balance = 1000000.00
//
//print(account.balance)
//
//// Introducing access control
//// Private
let johnChecking = CheckingAccount()
johnChecking.deposit(amount: 300.00)
//
let check = johnChecking.writeCheck(amount: 200.00)!
//
let janeChecking = CheckingAccount()
janeChecking.deposit(check: check)
print(janeChecking.balance)
janeChecking.deposit(check: check)
print(janeChecking.balance)
//

class SavingsAccount: BasicAccount {
    var interestRate : Double
    
    init(interestRate: Double) {
        self.interestRate = interestRate
    }
    
    func processInterest(){
        let interest = balance * interestRate
        deposit(amount: interest)
    }
}

/* Mini exercises page 292 
  1. Create a struct Person in a new Sources file. This struct should have first, last and fullName properties that are readable but not writable by the playground.
 2. Create a similar type, except make it a class and call it ClassyPerson. In the playground, subclass ClassyPerson with class Doctor and make a doctor's fullName print the prefix "Dr.".
 */
let ivar = Person(first: "Ivar", last: "Larsen")
print(ivar.fullName)

class Doctor : ClassyPerson {
    override var fullName: String {
        return "Dr. \(super.fullName)"
    }
}
let who = Doctor(first: "The", last: "Doctor")
print(who.fullName)


// Organising code into extensions

fileprivate var issuedChecks: [Int] = []
fileprivate var currentCheck = 1

private extension CheckingAccount {
    func inspectorForFraud(with checkNumber: Int) -> Bool {
        return issuedChecks.contains(checkNumber)
    }
    func nextNumber() -> Int {
        let next = currentCheck
        currentCheck += 1
        return next
    }
}
extension CheckingAccount: CustomStringConvertible {
    public var description: String {
        return "Checking balance: $\(balance)"
    }
}


/* CHALLENGES page 294 */

/* A: Singleton pattern 
 A singleton is a design pattern that restricts the instantiation of a class to one object.
 Use access modifiers to create a singleton class Logger. This Logger should: 
    Provide shared, public, global access to the single Logger object.
    Not be able to be instantiated by consuming code
    Have a method log() that will print a string to the console
*/
print("\nChallenge A:")
class Logger {

    private init() {}
    
    static let singleLoggerObject = Logger()
    
    func log(_ loggerString: String) {
        print(loggerString)
    }
}
Logger.singleLoggerObject.log("Log this!")
Logger.singleLoggerObject.log("And this...")

/* B: Stack 
 Declare a generic type Stack. A stack is a LIFO (last-in-first-out) data structure that supports the following operations:
 • peek: returns the top element on the stack without removing it. Returns nil if the stack is empty.
 • push: adds an element on top of the stack.
 • pop: returns and removes the top element on the stack. Returns nil if the stack
 is empty.
 • count: returns the size of the stack.
 Ensure that these operations are the only exposed interface. In other words, additional properties or methods needed to implement the type should not be visible.
 */
print("\nChallenge B:")
struct Stack<Element> {
    private var items : [Element] = []
    
    func peek() -> Element? {
        return items.last
    }
    mutating func push(_ newItem: Element) {
        items.append(newItem)
    }
    mutating func pop() -> Element? {
        if items.isEmpty {
            return nil
        }
        return items.removeLast()
    }
    func count() -> Int {
        return items.count
    }
}
var items = Stack<Int>()
items.push(3)
items.push(5)
items.push(7)
items.push(9)
items.count()
items.peek()
print(items)

while let item = items.pop(){
    Logger.singleLoggerObject.log(String(item))
}

/* C: Character battle
 Utilize something called a static factory method to create a game of Wizards vs. Elves vs. Giants.
 Add a file Characters.swift in the Sources folder of your playground.
 To begin:
 • Create an enum GameCharacterType that defines values for elf, giant,and wizard.
 • Create a class protocol GameCharacter that has properties name, hitPoints and attackPoints. Implement this protocol for every character type.
 • Create a struct GameCharacterFactory with a single static method make(ofType: GameCharacterType) -> GameCharacter.
 • Create a global function battle that pits 2 characters against each other — with the first character striking first! If a character reaches 0 hit points, they have lost.
 Notes:
 • The playground should not be able to see the concrete types that implement
 GameCharacter.
 • Elves have 3 hit points, and 10 attack points. Wizards have 5 hit points and 5
 attack points. Giants have 10 hit points and 3 attack points.
 • The playground should know none of the above!
 In your playground, you should use the following scenario as a test case:
 
 let elf = GameCharacterFactory.make(ofType: .elf)
 let giant = GameCharacterFactory.make(ofType: .giant)
 let wizard = GameCharacterFactory.make(ofType: .wizard)
 battle(elf, vs: giant) // Both players still active!
 battle(wizard, vs: giant) // Giant defeated!
 battle(wizard, vs: elf) // Wizard defeated!
 
 */
print("\nChallenge C:")
var elf = GameCharacterFactory.make(ofType: .elf)
var giant = GameCharacterFactory.make(ofType: .giant)
var wizard = GameCharacterFactory.make(ofType: .wizard)
battle(elf, vs: giant) // Both players still active!
battle(wizard, vs: giant) // Giant defeated!
battle(wizard, vs: elf) // Wizard defeated!


