import Cocoa

/* 
 • Create an enum GameCharacterType that defines values for elf, giant, and wizard.
 • Create a class protocol GameCharacter that has properties name, hitPoints and attackPoints. Implement this protocol for every character type.
 • Create a struct GameCharacterFactory with a single static method make(ofType: GameCharacterType) -> GameCharacter.
 • Create a global function battle that pits 2 characters against each other — with the first character striking first! If a character reaches 0 hit points, they have lost.
 • The playground should not be able to see the concrete types that implement GameCharacter.
 • Elves have 3 hit points, and 10 attack points. Wizards have 5 hit points and 5
    attack points. Giants have 10 hit points and 3 attack points.
 • The playground should know none of the above!
*/

public enum GameCharacterType {
    case elf
    case giant
    case wizard
}
public protocol GameCharacter {
    var name: String { get }
    var hitPoints: Int { get set }
    var attackPoints: Int { get }
}

class Elf: GameCharacter {
    let name = "Elf"
    var hitPoints = 3
    let attackPoints = 10
}
class Giant: GameCharacter {
    let name = "Giant"
    var hitPoints = 10
    let attackPoints = 3
}
class Wizard: GameCharacter {
    let name = "Wizard"
    var hitPoints = 5
    let attackPoints = 5
}
public struct GameCharacterFactory {
    static public func make(ofType type: GameCharacterType) -> GameCharacter {
        switch type {
        case .elf:
            return Elf()
        case .giant:
            return Giant()
        case .wizard:
            return Wizard()
        }
    }
}
public func battle(_ firstCharacter: GameCharacter, vs secondCharacter: GameCharacter) {
    var firstCharacter = firstCharacter
    var secondCharacter = secondCharacter
    
    secondCharacter.hitPoints -= firstCharacter.attackPoints
    
    if secondCharacter.hitPoints <= 0 {
        print("\(secondCharacter.name) defeated!")
        return
    }
    
    firstCharacter.hitPoints -= secondCharacter.attackPoints
    
    if firstCharacter.hitPoints <= 0 {
        print("\(firstCharacter.name) defeated!")
        return
    }
    print("Both players still active!")
}

