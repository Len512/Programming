import Cocoa

public struct Person {
    private(set) var first: String
    private(set) var last: String
    public var fullName: String {
        return "\(first) \(last)"
    }
    public init(first: String, last: String){
        self.first = first
        self.last = last
    }
}

open class ClassyPerson {
    
    private(set) var first: String
    private(set) var last: String
    
    open var fullName: String {
        return "\(first) \(last)"
    }
    
    public init(first: String, last: String) {
        self.first = first
        self.last = last
    }
}
