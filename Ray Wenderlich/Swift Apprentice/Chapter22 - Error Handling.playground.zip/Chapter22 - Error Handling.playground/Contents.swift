import Cocoa

// Failable initialisers

let value = Int("3")
let failedValue = Int("nope")

enum PetFood: String {
    case kibble, canned
}

let morning = PetFood.init(rawValue: "kibble")
let snack = PetFood.init(rawValue: "fuud!")

/* By using a failable initialiser you can guarantee that your 
 instance has the correct attributes or it will never exist because 
 it will return nil if it fails */
struct PetHouse {
    let squareFeet: Int
    init?(squareFeet: Int) {
        if squareFeet < 1 {
            return nil
        }
        self.squareFeet = squareFeet
    }
}
let tooSmall = PetHouse(squareFeet: 0)
let house = PetHouse(squareFeet: 1)

// Optional chaining

/* Force unwrap is appropriate only when an optional must contain a value. */
//class Pet {
//    var breed: String?
//    
//    init(breed: String? = nil){
//        self.breed = breed
//    }
//}
//class Person {
//    let pet: Pet
//    
//    init(pet: Pet) {
//        self.pet = pet
//    }
//}
//let delia = Pet(breed: "pug")
//let olive = Pet()
//
//let janie = Person(pet: olive)
//let dogBreed = janie.pet.breed // Force unwrapping this causes en error
//
//if let dogBreed = janie.pet.breed {
//    print("Olive is a \(dogBreed)")
//} else {
//    print("Olive's breed is unknown")
//}
//

class Toy {
    enum Kind {
        case ball, zombie, bone, mouse
    }
    enum Sound {
        case squeak, bell
    }
    
    let kind: Kind
    let colour: String
    
    var sound: Sound?
    
    init(kind: Kind, colour: String, sound: Sound? = nil) {
        self.kind = kind
        self.colour = colour
        self.sound = sound
    }
}
class Pet {
    enum Kind {
        case dog, cat, guineaPig
    }
    let name: String
    let kind: Kind
    let favouriteToy: Toy?
    
    init(name: String, kind: Kind, favouriteToy: Toy? = nil) {
        self.name = name
        self.kind = kind
        self.favouriteToy = favouriteToy
    }
}
class Person {
    let pet: Pet?
    
    init(pet: Pet? = nil) {
        self.pet = pet
    }
}

let janie = Person(pet: Pet(name: "Delia", kind: .dog, favouriteToy: Toy(kind: .ball, colour: "Purple", sound: .bell)))
let tammy = Person(pet: Pet(name: "Evil Cat Overlord", kind: .cat, favouriteToy: Toy(kind: .mouse, colour: "Orange")))
let felipe = Person()

// Check if any of the team members has a pet with a favourite toy that makes a sound -> use optional chaining
if let sound = janie.pet?.favouriteToy?.sound {
    print("Sound \(sound)")
} else {
    print("No sound")
}
if let sound = tammy.pet?.favouriteToy?.sound {
    print("Sound \(sound)")
} else {
    print("No sound")
}
if let sound = felipe.pet?.favouriteToy?.sound {
    print("Sound \(sound)")
} else {
    print("No sound")
}
// Map and flatmap
let team = [janie, tammy, felipe]
let petNames = team.map{
    $0.pet?.name
}
for pet in petNames {
    print(pet)
}
// use flatmap to unwrap all the values that are not nil
// flatMap does a regular map operation and simplifies the results
let betterPetNames = team.flatMap {
    $0.pet?.name
}
for pet in betterPetNames {
    print(pet)
}

// Error protocol

class Pastry {
    let flavour: String
    var numberOnHand: Int
    
    init(flavour: String, numberOnHand: Int) {
        self.flavour = flavour
        self.numberOnHand = numberOnHand
    }
}

enum BakeryError: Error {
    case tooFew(numberOnHand: Int)
    case doNotSell
    case wrongFlavour
}

class Bakery {
    var itemsForSale = [
        "Cookie" : Pastry(flavour: "ChocolateChip", numberOnHand: 20),
        "PopTart" : Pastry(flavour: "WildBerry", numberOnHand: 13),
        "Donut" : Pastry(flavour: "Sprinkles", numberOnHand: 24),
        "HandPie" : Pastry(flavour: "Cherry", numberOnHand: 6)
    ]
    
    func orderPastry(item: String, amountRequested: Int, flavour: String) throws -> Int {
        guard let pastry = itemsForSale[item] else {
            throw BakeryError.doNotSell
        }
        guard flavour == pastry.flavour else {
            throw BakeryError.wrongFlavour
        }
        guard amountRequested <= pastry.numberOnHand else {
            throw BakeryError.tooFew(numberOnHand: pastry.numberOnHand)
        }
        pastry.numberOnHand -= amountRequested
        return pastry.numberOnHand
    }
}

let bakery = Bakery()
do {
    try bakery.orderPastry(item: "Albatross", amountRequested: 1, flavour: "AlbatrossFlavour")
} catch BakeryError.doNotSell {
    print("Sorry, but we don't sell albatross")
} catch BakeryError.wrongFlavour {
    print("Sorry, but we don't carry albatross flavour")
} catch BakeryError.tooFew {
    print("Sorry, we don't have enough albatross to fulfill your order")
}

// Not looking at the detailed error 
let remaining = try? bakery.orderPastry(item: "Albatross", amountRequested: 1, flavour: "AlbatrossFlavour")

do {
    try bakery.orderPastry(item: "Cookie", amountRequested: 1, flavour: "ChocolateChip")
} catch {
    fatalError()
}
// the same as above, but shorter
try! bakery.orderPastry(item: "Cookie", amountRequested: 1, flavour: "ChocolateChip")

// Advanced error handling
// See Chapter22 - PugBot.playground

