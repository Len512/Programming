import Cocoa

// Method refresher

let months = ["January", "February", "March",
              "April", "May", "June",
              "July", "August", "September",
              "October", "November", "December"]

struct SimpleDate1 {
    var month: String
    func monthsUntilWinterBreak1(from date: SimpleDate1) -> Int {
        return months.index(of: "December")! - months.index(of: date.month)!
    }
    func monthsUntilWinterBreak() -> Int {
        return months.index(of: "December")! - months.index(of: self.month)!
    }
}
let date1 = SimpleDate1(month: "October")
let monthsLeft0 = date1.monthsUntilWinterBreak1(from: date1)
let monthsLeft1 = date1.monthsUntilWinterBreak()

/* Mini exercise page 188 - Introducing self 
 Since monthsUntilWinterBreak() returns a single value and there’s not much calculation involved, 
    transform the method into a computed property with a getter component.
 */

struct SimpleDate2 {
    var month: String
    var monthsUntilWinterBreak : Int {
        get {
            return months.index(of: "December")! - months.index(of: self.month)!
        }
    }
}
let date2 = SimpleDate2(month: "June")
let monthsLeft2 = date2.monthsUntilWinterBreak

// Introducing initialisers

struct SimpleDate3 {
    var month: String
    init() {
        month = "March"
    }
    func monthsUntilWinterBreak() -> Int {
        return months.index(of: "December")! - months.index(of: month)!
    }
}

let date3 = SimpleDate3()
let month3 = date3.month
let monthsLeft3 = date3.monthsUntilWinterBreak()

// Initialisers in structures

struct SimpleDate4 {
    var month: String
    var day: Int
    
    init() {
        month = "March"
        day = 1
    }
    init(month: String, day: Int) {
        self.month = month
        self.day = day
    }
}
let date4 = SimpleDate4(month: "February", day: 14)
let month4 = date4.month
let day4 = date4.day

/* Mini exercise page 193 - Type methods
    Add a type method to the Math structure that calculates the _n_th triangle number. 
    It will be very similar to the factorial formula, except instead of multiplying the numbers, you add them.
 */

struct Math {
    static func factorial(of number: Int) -> Int {
        return (1...number).reduce(1, *)
    }
    static func triangle(n position: Int) -> Int {
        return (1...position).reduce(0, +)
    }
}
let factorial = Math.factorial(of: 6)
let triangle = Math.triangle(n: 6)

// Adding to an existing structure with extensions
extension Math {
    static func primeFactors(of value: Int) -> [Int] {
        var remainingValue = value
        var testFactor = 2
        var primes: [Int] = []
        
        while testFactor * testFactor <= remainingValue {
            if remainingValue % testFactor == 0 {
                primes.append(testFactor)
                remainingValue /= testFactor
            } else {
                testFactor += 1
            }
        }
        if remainingValue > 1 {
            primes.append(remainingValue)
        }
        return primes
    }
}

/* CHALLENGES page 195 */
/* 1. Given the Circle structure below: 
 struct Circle {
 var radius = 0.0
 var area: Double {
 return .pi * radius * radius
 }
 init (radius: Double) {
 self.radius = radius
 }
 }
 Write a method that can change an instance's area by a growth factor. 
    For example, if you call circle.grow(byFactor: 3), the area of the instance will triple.
 Hint: add a setter to area
 */

struct Circle {
    var radius = 0.0
    var area: Double {
        get {
            return .pi * radius * radius
        }
        set {
            radius = sqrt(newValue / .pi)
        }
    }
    init (radius: Double) {
        self.radius = radius
    }
    mutating func grow(byFactor factor: Double) {
        area = area * factor
    }
}

var circle = Circle(radius: 3)
var circleArea = circle.area
circle.grow(byFactor: 3)
circleArea = circle.area


/* 2. Below is a naive way of writing advance() for the SimpleDate structure you saw earlier in the chapter:

struct SimpleDate {
    var month: String
    var day: Int
    init(month: String, day: Int) {
        self.month = month
        self.day = day
    }
    mutating func advance() {
        day += 1 }
}
var current = SimpleDate(month: "December", day: 31)
current.advance()
let currentMonth = current.month // December; should be January!
let currentDay = current.day // 32; should be 1!

What happens when the function should go from the end of one month to the start of the next? 
 Rewrite advance() to account for advancing from December 31st to January 1st. */

struct SimpleDate {
    var month: String
    var day: Int
    init(month: String, day: Int) {
        self.month = month
        self.day = day
    }
    mutating func advance() {
        let newMonthIndex = (month == "December") ? 0 : (months.index(of: month)! + 1)
        
        if month == "February" && day == 28 {
            day = 1
            month = "March"
        } else if day == 30 && (month == "April" || month == "June" || month == "September" || month == "November") {
            day = 1
            month = months[newMonthIndex]
        } else if day == 31 {
            day = 1
            month = months[newMonthIndex]
        } else {
            day += 1
        }
    }
}
var current = SimpleDate(month: "December", day: 31)
current.advance()
let currentMonth = current.month // December; should be January!
let currentDay = current.day // 32; should be 1!


/* 3. Add type methods to your Math namespace called isEven and isOdd that 
 return true if the number is even or odd respectively. */
extension Math {
    static func isOdd(number num: Int) -> Bool {
        return (num % 2 == 1) ? true : false
    }
    static func isEven(number num: Int) -> Bool {
        return (num % 2 == 0) ? true : false
    }
}

Math.isOdd(number: 11)
Math.isEven(number: 11)
Math.isOdd(number: 2)
Math.isEven(number: 2)

/* 4. It turns out that Int is just a struct.  Add the computed properties isEven and isOdd to Int 
    using an extension. (Note: Generally, you want to be careful about what functionality you add to 
    standard library types as it can cause confusion for readers.)*/
extension Int {
    var isOdd: Bool {
        return (self % 2 == 1) ? true : false
    }
    var isEven: Bool {
        return (self % 2 == 0) ? true : false
    }
}

11.isOdd
11.isEven
100.isOdd
100.isEven

/* 5. Add the method primeFactors() to Int.  Note: Since this is an expensive operation, 
    this is best left as an actual method. (Note: This method is probably not a good addition 
    to the standard library Int because of confusion it might cause. It is good for learning in the playground though!)*/
extension Int {
    func primeFactors() -> [Int] {
        var remainingValue = self
        var testFactor = 2
        var primes: [Int] = []
        
        while testFactor * testFactor <= remainingValue {
            if remainingValue % testFactor == 0 {
                primes.append(testFactor)
                remainingValue /= testFactor
            } else {
                testFactor += 1
            }
        }
        if remainingValue > 1 {
            primes.append(remainingValue)
        }
        return primes
    }
}

11.primeFactors()
66.primeFactors()
18.primeFactors()
10.primeFactors()


