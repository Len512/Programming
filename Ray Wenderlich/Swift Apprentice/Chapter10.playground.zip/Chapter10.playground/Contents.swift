//: Playground - noun: a place where people can play

import Cocoa

// Closure basics

var multiplyClosure: (Int, Int) -> Int

multiplyClosure = {
    $0 * $1
}
let result1 = multiplyClosure(4, 2)

func operateOnNumbers (_ a: Int, _ b: Int, operation: (Int, Int) -> Int) -> Int {
    let result = operation(a, b)
    print(result)
    return result
}
let addClosure = { (a: Int, b: Int) in
    a + b
}
operateOnNumbers(4, 2, operation: addClosure)

func addFunction(_ a: Int, _ b: Int) -> Int {
    return a + b
}
operateOnNumbers(4, 2, operation: addFunction)
operateOnNumbers(4, 2, operation: { (a: Int, b: Int) -> Int in
    return a + b
})
operateOnNumbers(4, 2, operation: { $0 + $1 })
operateOnNumbers(4, 2, operation: +)
// if the closure is the final parameter
operateOnNumbers(2, 4) {
    $0 + $1
}

let voidClosure: () -> Void = {
    print("Swift Apprentice is awesome!")
}
voidClosure()

func countingClosure() -> (() -> Int) {
    var counter = 0
    let incrementCounter: () -> Int = {
        counter += 1
        return counter
    }
    return incrementCounter
}
let counter1 = countingClosure()
let counter2 = countingClosure()
counter1()
counter2()
counter1()
counter2()
counter2()
counter1()
counter2()

// Custom sorting with closures
let names1 = ["ZZZZZZ", "BB", "A", "CCCC", "EEEEE"]
names1.sorted()

names1.sorted {
    $0.characters.count > $1.characters.count
}

// Iterating over collections with closures
var prices = [1.5, 10, 4.99, 2.30, 8.19]

let largePrices = prices.filter {
    return $0 > 5
}

let salePrices = prices.map {
    return $0 * 0.9
}

let sum = prices.reduce(0) {
    return $0 + $1
}

let stock = [1.5:5, 10:2, 4.99:20, 2.30:5, 8.19:30]
let stockSum = stock.reduce(0) {
    return $0 + $1.key * Double($1.value)
}

let removeFirst = prices.dropFirst()
let removeFirst2 = prices.dropFirst(2)

let firstTwo = prices.prefix(2)
let lastTwo = prices.suffix(2)

/* Mini exercises page 155 - Closure basics 
 1. Create a constant array called names which contains some names as strings (any names will do — make sure there’s more than three though!). Now use reduce to create a string which is the concatenation of each name in the array.
 2. Using the same names array, first filter the array to contain only names which have more than four characters in them, and then create the same concatenation of names as in the above exercise. (Hint: you can chain these operations together.)
 3. Create a constant dictionary called namesAndAges which contains some names as strings mapped to ages as integers. Now use filter to create a dictionary containing only people under the age of 18.
 4. Using the same namesAndAgesdictionary, filter out the adults (those 18 or older) and then use map to convert to an array containing just the names (i.e. drop the ages).
 */
// 1
let names = ["Erin", "Bjørn", "Oddvar", "Ida", "Ragnar", "Einar"]
let concatenatedNames = names.reduce("") {
    $0 + $1
}
print(concatenatedNames)
// 2
let concatenatedLargeNames = names.filter {
    $0.characters.count > 4
}.reduce(""){
    $0 + $1
}
print(concatenatedLargeNames)
// 3
let namesAndAges = ["Erin" : 15, "Bjørn": 24, "Oddvar": 5, "Ida": 45, "Ragnar": 60, "Einar": 36]
let under18 = namesAndAges.filter {
    $0.value < 18
}
print("Under 18: \(under18)")
// 4
let adults = namesAndAges.filter {
    $0.value >= 18
}.map {
    return $0.key
}
print("Adults: \(adults)")


/* CHALLENGES page 157 */

/* A: Repeating yourself
 Your first challenge is to write a function that will run a given closure a given number of times.
 Declare the function like so:
 func repeatTask(times: Int, task: () -> Void)
 The function should run the task closure, times number of times.
 Use this function to print "Swift Apprentice is a great book!" 10 times.
 */
func repeatTask(times: Int, task: () -> Void) {
    for _ in 1...times {
        task()
    }
}
repeatTask(times: 10, task: {
    print("Swift Apprentice is a great book!")
})

/* B: Closure sums
 In this challenge, you’re going to write a function that you can reuse to create different mathematical sums.
 Declare the function like so:
 func mathSum(length: Int, series: (Int) -> Int) -> Int
 The first parameter, length, defines the number of values to sum. 
 The second parameter, series, is a closure that can be used to generate a series of values. 
    series should have a parameter that is the position of the value in the series and return the value at that position.
 mathSum should calculate length number of values, starting at position 1, and return their sum.
 Use the function to find the sum of the first 10 square numbers, which equals 385. 
    Then use the function to find the sum of the first 10 Fibonacci numbers, which equals 143. 
    For the Fibonacci numbers, you can use the function you wrote in the functions chapter — 
    or grab it from the solutions if you’re unsure your solution is correct.
 */
func mathSum(length: Int, series: (Int) -> Int) -> Int {
    var seriesValues = [Int]()
    for at in 1...length {
        seriesValues.append(series(at))
    }
    let sum = seriesValues.reduce(0) {
        $0 + $1
    }
    return sum
}
let squareSum = mathSum(length: 10, series: { $0 * $0 })
print(squareSum)

func fibonacci(_ number: Int) -> Int {
    if number <= 0 {
        return 0
    }
    if number == 1 || number == 2 {
        return 1
    }
    return fibonacci(number - 1) + fibonacci(number - 2)
}

let fibonacciSum = mathSum(length: 10, series: fibonacci)
print(fibonacciSum)

/* C: Functional ratings 
 In this final challenge you will have a list of app names with associated ratings they’ve been given 
    (note — these are all fictional apps!). Create the data dictionary like so:
 let appRatings = [
 "Calendar Pro": [1, 5, 5, 4, 2, 1, 5, 4],
 "The Messenger": [5, 4, 2, 5, 4, 1, 1, 2],
 "Socialise": [2, 1, 2, 2, 1, 2, 4, 2]
 ]
 First, create a dictionary called averageRatings which will contain a mapping of app names to average ratings. 
 Then, use forEach to iterate through the appRatings dictionary, use reduce to calculate the average rating
    and store this rating in the averageRatings dictionary.
 Finally, use filter and map chained together to get a list of the app names whose average rating is greater than 3.
 */
let appRatings = [
    "Calendar Pro": [1, 5, 5, 4, 2, 1, 5, 4],
    "The Messenger": [5, 4, 2, 5, 4, 1, 1, 2],
    "Socialise": [2, 1, 2, 2, 1, 2, 4, 2]
]
var averageRatings = [String: Double]()
appRatings.forEach {
    let sumOfRatings = $0.value.reduce(0){ $0 + $1 }
    averageRatings[$0.key] = Double(sumOfRatings) / Double($0.value.count)
}
print(averageRatings)

let popularApps = averageRatings.filter {
    $0.value > 3
    }.map {
        $0.key
    }
print(popularApps)




