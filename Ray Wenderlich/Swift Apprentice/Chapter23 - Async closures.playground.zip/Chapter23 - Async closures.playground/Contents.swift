import Cocoa
import PlaygroundSupport
// Reference cycles for classes

// Using weak references 

//class Tutorial {
//    let title : String
//    let category : String
//    let date : Date
//    var editor : Editor?
//    
//    init(title: String, category: String, date: Date) {
//        self.title = title
//        self.category = category
//        self.date = date
//    }
//    deinit {
//        print("Goodbye \(title)!")
//    }
//}
//
//class Editor {
//    let name: String
//    let email: String
//    weak var tutorial: Tutorial?
//    
//    init(name: String, email: String) {
//        self.name = name
//        self.email = email
//    }
//    deinit {
//        print("Goodbye \(name)!")
//    }
//}
//
//var tutorial: Tutorial? = Tutorial(title: "Memory management", category: "Swift", date: Date())
//var editor : Editor? = Editor(name: "Ray", email: "ray@whatever.com")
//
//tutorial?.editor = editor
//editor?.tutorial = tutorial
//
//tutorial = nil
//editor = nil

// Using unowned references 

class Tutorial {
    let title : String
    let category : String
    let date : Date
    var editor : Editor?
    unowned let author: Author
    
    
    init(title: String, category: String, date: Date, author: Author) {
        self.title = title
        self.category = category
        self.date = date
        self.author = author
    }
    deinit {
        print("Goodbye \(title)!")
    }
    
    lazy var tutorialDescription: () -> String = {
        [unowned self] in
        return "\(self.title) \(self.category)"
    }
}

class Editor {
    let name: String
    let email: String
    weak var tutorial: Tutorial?

    init(name: String, email: String) {
        self.name = name
        self.email = email
    }
    deinit {
        print("Goodbye \(name)!")
    }
}

class Author {
    let name: String
    let email: String
    var tutorial: Tutorial?
    
    init(name: String, email: String) {
        self.name = name
        self.email = email
    }
    deinit {
        print("Goodbye \(name)!")
    }
}

var author : Author? = Author(name: "Cosmin", email: "cosmin@whatever.com")
var tutorial : Tutorial? = Tutorial(title: "Memory management", category: "Swift", date: Date(), author: author!)
var editor : Editor? = Editor(name: "Ray", email: "ray@whatever.com")

print(tutorial!.tutorialDescription())

tutorial?.editor = editor
editor?.tutorial = tutorial
author?.tutorial = tutorial
author = nil
tutorial = nil
editor = nil

// Reference cycles for closures 
// added tutorial description at line 66 and print statement at line 104

// Capture lists 
// a capture list is an array of variables which are captured by a closure

var counter = 0
var closure = { [counter] in print(counter) } // Copies the value of counter into a new local constant (not reference type)
counter = 1
closure()

// to break the reference cycle (now only the Author gets removed), 
// we need to change the strong reference of the closure in the description variable

// Handling asynchronous closures through Grand Central Dispatch - GCD

func log(message: String) {
    let thread = Thread.current.isMainThread ? "Main" : "Background"
    print("\(thread) thread: \(message)")
}
func addNumbers(range: Int) -> Int {
    log(message: "Adding numbers...")
    return (1...range).reduce(0, +)
}
let queue = DispatchQueue(label: "queue") // serial queue (FIFO)

// the function is generic and mark both closures as @escaping because they get called after the function returns
func execute<T>(backgroundWork: @escaping () -> T, mainWork: @escaping (T) -> ()) {
    queue.async {
        // run this closure asynchronously
        let result = backgroundWork()
        
        // dispatch asynchronously on the main queue and use the result of the other closure
        DispatchQueue.main.async {
            mainWork(result)
        }
    }
}

PlaygroundPage.current.needsIndefiniteExecution = true

//execute(backgroundWork: { addNumbers(range: 100)}, mainWork: { log(message: "The sum is \($0)") })

// Sometimes self cannot be captured as an unowned reference because it may become nil at some point while running an async task

// Weak self 

extension Editor {
    var feedback: String {
        let tutorialStatus: String
        if arc4random_uniform(10) % 2 == 0 {
            tutorialStatus = "published"
        } else {
            tutorialStatus = "rejected"
        }
        return "Tutorial \(tutorialStatus) by \(self.name)"
    }
    // If the editors goes out of scope, make them disappear
    // it they are still around when the closure executes, perform the edit
    
    // to allow this, create a temporary strong reference to self
    
    func editTutorial() {
        queue.async() {
            [weak self] in
            guard let strongSelf = self else {
                return
            }
            DispatchQueue.main.async {
                print(strongSelf.feedback)
            }
        }
    }
}

/* CHALLENGES page 352 */

/* A: 
 Break the strong reference cycle in the following code: 
 class Person {
 let name: String
 let email: String
 var car: Car?
 init(name: String, email: String) {
 self.name = name
 self.email = email
 }
 deinit {
 print("Goodbye \(name)!")
 }
 }
 class Car {
 let id: Int
 let type: String
 var owner: Person?
 init(id: Int, type: String) {
 self.id = id
 self.type = type
 }
 deinit {
 print("Goodbye \(type)!")
 }
 }
 var owner: Person? = Person(name: "Cosmin", email: "cosmin@whatever.com")
 var car: Car? = Car(id: 10, type: "BMW")
 owner?.car = car
 car?.owner = owner
 owner = nil
 car = nil
*/
class Person {
    let name: String
    let email: String
    weak var car: Car?
    init(name: String, email: String) {
        self.name = name
        self.email = email
    }
    deinit {
        print("Goodbye \(name)!")
    }
}
class Car {
    let id: Int
    let type: String
    var owner: Person?
    init(id: Int, type: String) {
        self.id = id
        self.type = type
    }
    deinit {
        print("Goodbye \(type)!")
    }
}
var owner: Person? = Person(name: "Cosmin", email: "cosmin@whatever.com")
var car: Car? = Car(id: 10, type: "BMW")
owner?.car = car
car?.owner = owner
owner = nil
car = nil

/* B: 
 Break the strong reference cycle in the following code: 
 class Customer {
 let name: String
 let email: String
 var account: Account?
 init(name: String, email: String) {
 self.name = name
 self.email = email
 }
 deinit {
 print("Goodbye \(name)!")
 }
 }
 class Account {
 let number: Int
 let type: String
 let customer: Customer
 init(number: Int, type: String, customer: Customer) {
 self.number = number
 self.type = type
 self.customer = customer
 }
 deinit {
 print("Goodbye \(type) account number \(number)!")
 }
 }
 var customer: Customer? = Customer(name: "George", email:
 "george@whatever.com")
 var account: Account? = Account(number: 10, type: "PayPal", customer:
 customer!)
 customer?.account = account
 account = nil
 customer = nil
*/
class Customer {
    let name: String
    let email: String
    var account: Account?
    init(name: String, email: String) {
        self.name = name
        self.email = email
    }
    deinit {
        print("Goodbye \(name)!")
    }
}
class Account {
    let number: Int
    let type: String
    unowned let customer: Customer
    init(number: Int, type: String, customer: Customer) {
        self.number = number
        self.type = type
        self.customer = customer
    }
    deinit {
        print("Goodbye \(type) account number \(number)!")
    }
}
var customer: Customer? = Customer(name: "George", email:
    "george@whatever.com")
var account: Account? = Account(number: 10, type: "PayPal", customer:
    customer!)
customer?.account = account
account = nil
customer = nil





