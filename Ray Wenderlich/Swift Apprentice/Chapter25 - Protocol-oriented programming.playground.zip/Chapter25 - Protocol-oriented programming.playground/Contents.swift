import Cocoa

// Introducing protocol extensions

extension String {
    func shout() {
        print(uppercased())
    }
}
"Swift is pretty cool!".shout()

protocol TeamRecord {
    var wins: Int { get }
    var losses: Int { get }
    var winningPercentage: Double { get }
}
extension TeamRecord {
    var gamesPlayed: Int {
        return wins + losses
    }
}

struct BaseballRecord: TeamRecord {
    var wins: Int
    var losses: Int
 //Removed after adding this to the extension
    var winningPercentage: Double {
        return Double(wins) / (Double(wins) + Double(losses))
    }
}

let sanFranciscoSwifts = BaseballRecord(wins: 10, losses: 5)
sanFranciscoSwifts.gamesPlayed

// Default implementations 

struct BasketballRecord: TeamRecord {
    var wins: Int
    var losses: Int
    let seasonLength = 82
// Removed after adding this to the extension
//    var winningPercentage: Double {
//        return Double(wins) / (Double(wins) + Double(losses))
//    }
}
extension TeamRecord {
    var winningPercentage: Double {
        return Double(wins) / (Double(wins) + Double(losses))
    }
}
let minneapolisFunctors = BasketballRecord(wins: 60, losses: 22)
minneapolisFunctors.winningPercentage

struct HockeyRecord: TeamRecord {
    var wins: Int
    var losses: Int
    var ties: Int
    
    var winningPercentage: Double {
        return Double(wins) / (Double(wins) + Double(losses) + Double(ties))
    }
}

let chicagoOptionals = BasketballRecord(wins: 10, losses: 6)
let phoenixStridables = HockeyRecord(wins: 8, losses: 7, ties: 1)

chicagoOptionals.winningPercentage
phoenixStridables.winningPercentage

/* Mini exercise page 372 
 Write a default implementation on CustomStringConvertible that will simply remind you 
    to implement description by returning Remember to implement CustomStringConvertible!.
 Once you have your default implementation, you can write code like this:
 struct MyStruct: CustomStringConvertible {}
 print(MyStruct())
 // should print "Remember to implement CustomStringConvertible!""
 */
extension CustomStringConvertible {
    var description: String {
        return "Remember to implement CustomStringConvertible!"
    }
}
struct MyStruct: CustomStringConvertible {}
print(MyStruct())

// Understanding protocol extension dispatching
protocol WinLoss {
    var wins: Int { get }
    var losses: Int { get }
}
extension WinLoss {
    var winningPercentage: Double {
        return Double(wins) / (Double(wins) + Double(losses))
    }
}
struct CricketRecord: WinLoss {
    var wins: Int
    var losses: Int
    var draws: Int
    
    var winningPercentage: Double {
        return Double(wins) / (Double(wins) + Double(losses) + Double(draws))
    }
}
let miamiTuples = CricketRecord(wins: 8, losses: 7, draws: 1)
let winLoss: WinLoss = miamiTuples

miamiTuples.winningPercentage
winLoss.winningPercentage


// Type constraints 
protocol PostSeasonEligible {
    var minimumWinsForPlayoffs: Int { get }
}
extension TeamRecord where Self: PostSeasonEligible {
    var isPlayoffEligible: Bool {
        return wins > minimumWinsForPlayoffs
    }
}
protocol Tieable {
    var ties: Int { get }
}
extension TeamRecord where Self: Tieable {
    var winningPercentage: Double {
        return Double(wins) / (Double(wins) + Double(losses) + Double(ties))
    }
}
struct RugbyRecord: TeamRecord, Tieable {
    var wins: Int
    var losses: Int
    var ties: Int
}
let rugbyRecord = RugbyRecord(wins: 8, losses: 7, ties: 1)
rugbyRecord.winningPercentage

/* Mini exercise page 375 
 Write a default implementation on CustomStringConvertible that will print the win/ loss record in the format 
    Wins - Losses for any TeamRecord type. For instance, if a team is 10 and 5, it should return 10 - 5.
 */
extension CustomStringConvertible where Self : TeamRecord {
    var description : String {
        return "\(wins) - \(losses)"
    }
}
struct TennisRecord: TeamRecord, CustomStringConvertible {
    var wins: Int
    var losses: Int
}
let tennisRecord = TennisRecord(wins: 7, losses: 3)
print(tennisRecord)

// Protocol oriented benefits 

// Programming to interfaces, not implementations

class TeamRecordBase {
    var wins = 0
    var losses = 0
    var winningPercentage : Double {
        return Double(wins) / (Double(wins) + Double(losses))
    }
}

// struct BaseballRecord : TeamRecordBase {} // error struct cannot inherit from class
class HockeyRecord2 : TeamRecordBase {
    var ties = 0
    override var winningPercentage: Double {
        return Double(wins) / (Double(wins) + Double(losses) + Double(ties))
    }
}

class TieableRecordBase : TeamRecordBase {
    var ties = 0
    override var winningPercentage: Double {
        return Double(wins) / (Double(wins) + Double(losses) + Double(ties))
    }
}
class HockeyRecord3 : TieableRecordBase {}
class CricketRecord3 : TieableRecordBase {}

// Traits, mixins and multiple inheritance 

protocol TieableRecord {
    var ties: Int { get }
}

protocol DivisionalRecord {
    var divisionalWins: Int { get }
    var divisionalLosses: Int { get }
}

protocol ScoreableRecord {
    var totalPoints: Int { get }
}

extension ScoreableRecord where Self: TieableRecord, Self: TeamRecord {
    var totalPoints: Int {
        return (2 * wins) + (1 * ties)
    }
}
struct NewHockeyRecord: TeamRecord, TieableRecord, DivisionalRecord, CustomStringConvertible, Equatable {
    var wins: Int
    var losses: Int
    var ties: Int
    var divisionalWins: Int
    var divisionalLosses: Int
    
    static func ==(lhs: NewHockeyRecord, rhs: NewHockeyRecord) -> Bool {
        return lhs.wins == rhs.wins && lhs.losses == rhs.losses && lhs.ties == rhs.ties
    }
    
    var description: String {
        return "\(wins) - \(losses) - \(ties)"
    }
}
var hockey1 = NewHockeyRecord(wins: 16, losses: 2, ties: 8, divisionalWins: 7, divisionalLosses: 1)
var hockey2 = NewHockeyRecord(wins: 16, losses: 2, ties: 8, divisionalWins: 5, divisionalLosses: 3)
var hockey3 = NewHockeyRecord(wins: 20, losses: 1, ties: 5, divisionalWins: 7, divisionalLosses: 1)

print(hockey1)
print(hockey2)
print(hockey3)

hockey1 == hockey2
hockey1 == hockey3

/* CHALLENGES page 381 */

/* Challenge A: Protocol extension practice 
 Suppose you own a retail store. You have food items, clothes and electronics. Begin with an Item protocol:
 protocol Item {
 var name: String { get }
 var clearance: Bool { get }
 var msrp: Double { get }
 var totalPrice: Double { get }
 }
 Fulfill the following requirements using primarily what you’ve learned about protocol-oriented programming. In other words, minimize the code in your classes, structs or enums.
 • Clothes do not have sales tax, but all other items have 7.5% sales tax.
 • When on clearance, food items are discounted 50%, clothes are discounted 25% and electronics are discounted 5%.
 • Items should implement CustomStringConvertible and return name. Food items should also print their expiration dates.
 */
protocol Item: CustomStringConvertible {
    var name: String { get }
    var clearance: Bool { get }
    var msrp: Double { get }
    var totalPrice: Double { get }
}
protocol SalesTaxeable {
    var salesTax: Double { get }
}
protocol Discountable {
    var discountedPrice : Double { get }
}

extension Item {
    var totalPrice: Double {
        return msrp
    }
    var description: String {
        return name
    }
}
extension Item where Self: SalesTaxeable {
    var totalPrice: Double {
        return msrp + msrp * salesTax
    }
}
extension Item where Self: Discountable {
    var totalPrice: Double {
        return discountedPrice
    }
}
extension Item where Self: SalesTaxeable, Self: Discountable {
    var totalPrice: Double {
        return discountedPrice + discountedPrice * salesTax
    }
}

struct Food: Item, SalesTaxeable, Discountable, CustomStringConvertible{
    var name: String
    var clearance: Bool
    var msrp: Double
    
    let salesTax = 0.075
    
    var discountedPrice: Double  {
        return msrp * (clearance ? 0.5 : 1.0)
    }
    
    var expirationDate: (month: Int, year: Int)
    
    var description: String {
        return "\(name), expires \(expirationDate.month)/\(expirationDate.year)"
    }
}

struct Clothes : Item, Discountable, CustomStringConvertible {
    var name: String
    var clearance: Bool
    var msrp: Double
    
    var discountedPrice: Double {
        return msrp * (clearance ? 0.25 : 1.0)
    }
}

struct Electronics : Item, SalesTaxeable, Discountable, CustomStringConvertible {
    var name: String
    var clearance: Bool
    var msrp: Double
    let salesTax: Double = 0.075
    
    var discountedPrice: Double {
        return msrp * (clearance ? 0.005 : 1.0)
    }
}
let food = Food(name: "milk", clearance: false, msrp: 16.0, expirationDate: (07,2017))
let clothes = Clothes(name: "trousers", clearance: false, msrp: 200.0)
let electronics = Electronics(name: "blender", clearance: false, msrp: 500.0)
let food2 = Food(name: "milk", clearance: true, msrp: 16.0, expirationDate: (07,2017))
let clothes2 = Clothes(name: "trousers", clearance: true, msrp: 200.0)
let electronics2 = Electronics(name: "blender", clearance: true, msrp: 500.0)


food.totalPrice
electronics.totalPrice
clothes.totalPrice
food2.totalPrice
electronics2.totalPrice
clothes2.totalPrice

/* B: Randomisation 
 Write a protocol extension on Sequence named randomized() 
    that will rearrange the elements in a somewhat random order. 
    You can test out your implementation on an ordinary Array, 
    which implements Sequence.
 
 Hints:
 Your method signature should be randomized() -> [Iterator.Element]. 
    The type [Iterator.Element] is an array of whatever type the Sequence holds, 
    such as String or Int, .
 You can call the arc4random_uniform() method like this: arc4random_uniform(2) 
    to randomly generate a 1 or 0 for your randomization algorithm.
 */

extension Sequence {
    func randomised() -> [Iterator.Element] {
        return self.sorted { _ in
            arc4random_uniform(2) == 0
        }
    }
}

let array = [7, 5, 3, 1, 9, 13]

array.randomised()
array.randomised()



