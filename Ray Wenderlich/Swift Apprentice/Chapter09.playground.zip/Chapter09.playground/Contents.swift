//: Playground - noun: a place where people can play

import Cocoa

// Creating dictionaries
var namesAndScores = ["Anna": 2, "Brian": 2, "Craig": 8, "Donna": 6]
print(namesAndScores)

// Accessing values
print(namesAndScores["Anna"])
print(namesAndScores["Greg"])

print(Array(namesAndScores.keys))
print(Array(namesAndScores.values))

// Modifying dictionaries
var bobData = ["name": "Bob", "profession": "Card player", "country": "USA"]
bobData.updateValue("CA", forKey: "state")
bobData["city"] = "San Fransisco"
print(bobData)

/* Mini exercise page 142 - Modifying dictionaries 
 Write a function that prints a given player's city and state
 */
func printCityAndState(_ playerData: [String: String]) {
    if let city = playerData["city"], let state = playerData["state"] {
        print("Player is from \(city), \(state)")
    } else {
        print("Player info is missing")
    }
}
printCityAndState(bobData)
var annaData = ["name": "Anna", "profession": "teacher", "country": "Switzerland", "city": "Zurich"]
printCityAndState(annaData)

bobData.updateValue("Bobby", forKey: "name")
bobData["profession"] = "mailman"
bobData.removeValue(forKey: "state")
bobData["city"] = nil

// Iterating through dictionaries
for (player, score) in namesAndScores {
    print("\(player) - \(score)")
}

/* CHALLENGES page 146 */

/* 1. Which of the following are valid statements? 
 
 1. let dict1: [Int, Int] = [:]
 2. let dict2 = [:]
 3. let dict3: [Int: Int] = [:]
 
 For the next four statements, use the following dictionary: 
 let dict4 = ["One": 1, "Two": 2, "Three": 3]
 
 4. dict4[1]
 5. dict4["One"]
 6. dict4["Zero"] = 0
 7. dict4[0] = "Zero"
 
 For the next three statements, use the following dictionary: 
 var dict5 = ["NY": "New York", "CA": "California"]
 8. dict5["NY"]
 9. dict5["WA"] = "Washington"
 10. dict5["CA"] = nil
 */
// 1. invalid (: instead of ,) , 2. invalid (no type declarations / inference), 3. valid
// let dict1: [Int, Int] = [:]
// let dict2 = [:]
let dict3: [Int: Int] = [:]

let dict4 = ["One": 1, "Two": 2, "Three": 3]
// 4. Invalid (keys are Strings), 5. valid (1), 6. Invalid, dict4 is not a var, 7. Invalid (keys are strings and values ara Ints)
// dict4[1]
dict4["One"]
// dict4["Zero"] = 0
// dict4[0] = "Zero"

var dict5 = ["NY": "New York", "CA": "California"]
// 8. Valid (New York), 9. Valid (adding new key-value pair), 10. valid (removes key CA)
dict5["NY"]
dict5["WA"] = "Washington"
dict5["CA"] = nil


/* 2. Replacing dictionary values.
 Write a function that swaps the values of two keys in a dictionary. 
 This is the function's signature: 
 func swappingValuesForKeys(_ key1: String, _ key2: String, in dictionary: [String: Int]) -> [String: Int]
 */
func swappingValuesForKeys(_ key1: String, _ key2: String, in dictionary: [String: Int]) -> [String: Int] {
    var swapped = dictionary
    let temp = swapped[key1]
    swapped[key1] = swapped[key2]
    swapped[key2] = temp
    return swapped
}
var result = swappingValuesForKeys("One", "Two", in: dict4)
print(dict4)
print(result)

/* 3. Given a dictionary with 2-letter state codes as keys and the full state name as values, 
    write a function that prints all the states whose name is longer than 8 characters. 
    For example, for this dictionary ["NY": "New York", "CA": "California"] the output would be "California".*/

func printLargeStateNames(_ dictionary: [String: String]) {
    for (_, value) in dictionary {
        if value.characters.count > 8 {
            print(value)
        }
    }
}
let dict6 = ["NY": "New York", "CA": "California"]
printLargeStateNames(dict6)

/* 4. Write a function that combines two dictionaries into one. If a certain key appears in both dictionaries, 
    ignore the pair from the first dictionary. This is the signature of the function: 
    func merging(dict1: [String: String], with dict2: [String: String]) -> [String: String]
*/
func merging(dict1: [String: String], with dict2: [String: String]) -> [String: String] {
    var merged = dict2
    let keys2 = Array(dict2.keys)
    for key1 in dict1.keys {
        if !keys2.contains(key1) {
            if let value = dict1[key1] {
                merged.updateValue(value, forKey: key1)
            }
        }
    }
    return merged
}
var test1 = ["NY": "NewYork", "CA": "California"]
var test2 = ["NY": "New York", "PA": "Pennsylvania"]
var merged = merging(dict1: test1, with: test2)
print(merged)

/* 5. Declare a function occurencesOfCharacters that calculates which characters occur in a string,
    as well as how often each of these characters occur. Return the result as a dictionary. 
    This is the function signature:
    func occurrencesOfCharacters(in text: String) -> [Character: Int]
 */

func occurrencesOfCharacters(in text: String) -> [Character: Int] {
    var parsedChars = [Character: Int]()
    
    for char in text.characters {
        if let parsedCount = parsedChars[char] {
            parsedChars[char] = parsedCount + 1
        } else {
            parsedChars[char] = 1
        }
    }
    return parsedChars
}
var parsed = occurrencesOfCharacters(in: "METALLICA")
print(parsed)

/* 6, Write a function that returns true if all the values of a dictionary [String: Int] are
    unique. Use a dictionary to test uniqueness. This is the function signature: 
    func isInvertible(_ dictionary: [String: Int]) -> Bool
 */
func isInvertible(_ dictionary: [String: Int]) -> Bool {
    
    let valueArray = Array(dictionary.values)
    let length = valueArray.count
    for (index, value) in valueArray.enumerated() {
        let startIndex = index + 1
        let temp = valueArray[startIndex..<length]
        if temp.contains(value) {
            return false
        }
    }
    return true
}
let test3 = ["one": 1, "two": 2, "three": 3]
let test4 = ["one": 1, "two": 2, "three": 3, "forty-two": 2]
print(isInvertible(test3))
print(isInvertible(test4))

/* 7. Write an invert function that takes a dictionary [String: Int] and creates a new inverted dictionary [Int: String] 
    where the values are the keys and the keys are the values. Note that for this function to work properly, the dictionary 
    must be invertible.  You can check this by using the function you created above to do precondition(isInvertible(input), 
    "this dictionary can't be inverted") at the beginning of your function body.  Your program will halt if this precondition 
    is not met. This is the function signature:
    func invert(_ input: [String: Int]) -> [Int: String]
 */
func invert(_ input: [String: Int]) -> [Int: String] {
    precondition(isInvertible(input), "This dictionary cannot be inverted")
    var inverted = [Int: String] ()
    for (key, value) in input {
        inverted[value] = key
    }
    return inverted
}
let inverted = invert(test3)
print(inverted)
//print(invert(test4))


/* 8. Write a function that takes a dictionary [String: Int16] and prints the keys and values alphabetically sorted by keys. 
    This is the function signature:
    func printSortedKeysAndValues(_ input: [String: Int16])
*/
func printSortedKeysAndValues(_ input: [String: Int16]) {
    let sortedKeys = Array(input.keys).sorted()
    for key in sortedKeys {
        if let value = input[key] {
            print("\(key) : \(value)")
        }
        // print("\(key) : \(input[key]!)")
    }
}
let test5: [String: Int16] = ["one": 1, "two": 2, "three": 3, "forty-two": 2]
printSortedKeysAndValues(test5)


/* 9. Given the dictionary:  
 var nameTitleLookup: [String: String?] = ["Mary": "Engineer", "Patrick": "Intern", "Ray": "Hacker"], 
 set the value of the key "Patrick" to nil and completely remove the key and value for "Ray".  */

var nameTitleLookup: [String: String?] = ["Mary": "Engineer", "Patrick": "Intern", "Ray": "Hacker"]
print(nameTitleLookup)
nameTitleLookup.updateValue(nil, forKey: "Patrick")
nameTitleLookup["Ray"] = nil
print(nameTitleLookup)

