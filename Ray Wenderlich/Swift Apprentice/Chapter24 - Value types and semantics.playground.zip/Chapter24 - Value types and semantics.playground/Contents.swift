import Cocoa

struct Colour: CustomStringConvertible {
    var red, green, blue : Double
    
    var description: String {
        return "r: \(red), g: \(green), b: \(blue)"
    }
}

extension Colour {
    static var black = Colour(red: 0, green: 0, blue: 0)
    static var white = Colour(red: 1, green: 1, blue: 1)
    static var blue = Colour(red: 0, green: 0, blue: 1)
    static var green = Colour(red: 0, green: 1, blue: 0)
}

class Bucket {
    var colour = Colour.blue
    var isRefilled = false
    
    func refill() {
        isRefilled = true
    }
    init(colour: Colour = Colour.blue) {
        self.colour = colour
    }
}
// Reference types 

let azurePaint = Bucket()

let wallBluePaint = azurePaint

wallBluePaint.isRefilled
azurePaint.refill()
wallBluePaint.isRefilled

// Value types 
extension Colour {
    mutating func darken() {
        red *= 0.9; green *= 0.9; blue *= 0.9
    }
}
var azure = Colour.blue
var wallBlue = azure
azure
wallBlue.darken()
azure

// Defining value semantics 

struct PaintingPlan {
    var accent = Colour.white // a value type
    var bucket = Bucket()     // a reference type
}

var artPlan = PaintingPlan()
var housePlan = artPlan
// when changing the colour in the housePlan it changes is in the artPlan too (even though it is a struct)
artPlan.bucket.colour // blue
housePlan.bucket.colour = Colour.green
artPlan.bucket.colour // GREEN :(

// to preserve value semantics, we need to make the mutation of the reference type invisible to users

struct PaintingPlan1 {
    var accent = Colour.white
    private var bucket = Bucket()
    var bucketColour: Colour {
        get {
            return bucket.colour
        }
        set {
//            if isKnownUniquelyReferenced(&bucket) {
//                bucket.colour = bucketColour
//            } else {
//                bucket = Bucket(colour: newValue)
//            }
            bucket = Bucket(colour: newValue)
        }
    }
}
var artPlan1 = PaintingPlan1()
var housePlan1 = artPlan1

artPlan1.bucketColour // blue
housePlan1.bucketColour = Colour.green
artPlan1.bucketColour // BLUE :)


/* CHALLENGES page 366 */


/* A: 
 Build a new type, Image, that represents a simple image. It should also provide 
    mutating functions that apply modifications to the image. Use copy-on-write 
    to economize use of memory in the case where a user defines a large array of 
    these identical images, and does not mutate any of them.
 To get you started, assume you are using the following Pixels class for the raw storage.
 private class Pixels {
 let size: Int
 let storage: UnsafeMutablePointer<UInt8>
 init(size: Int, value: UInt8) {
 self.size = size
 storage = UnsafeMutablePointer<UInt8>.allocate(capacity: size)
 storage.initialize(from: repeatElement(value, count: size))
 }
 init(pixels: Pixels) {
 self.size = pixels.size
 storage = UnsafeMutablePointer<UInt8>.allocate(capacity: size)
 storage.initialize(from: pixels.storage, count: pixels.size)
 }
 subscript(offset: Int) -> UInt8 {
 get {
 return storage[offset]
 }
 set {
 storage[offset] = newValue
 }
 }
 deinit {
 storage.deallocate(capacity: size)
 }
 }
 Your image should be able to set and get individual pixel values 
    as well as set all the values at once. Typical usage:
 var image1 = Image(width: 4, height: 4, value: 0)
 // test setting and getting
 image1[0,0] // -> 0
 image1[0,0] = 100
 image1[0,0] // -> 100
 image1[1,1] // -> 0
 // copy
 var image2 = image1
 image2[0,0] // -> 100
 image1[0,0] = 2
 image1[0,0] // -> 2
 image2[0,0] // -> 100 because of copy-on-write
 var image3 = image2
 image3.clear(with: 255)
 image3[0,0] // -> 255
 image2[0,0] // -> 100 thanks again, copy-on-write
 
 */
private class Pixels {
    let size: Int
    let storage: UnsafeMutablePointer<UInt8>
    
    init(size: Int, value: UInt8) {
        self.size = size
        storage = UnsafeMutablePointer<UInt8>.allocate(capacity: size)
        storage.initialize(from: repeatElement(value, count: size))
    }
    
    init(pixels: Pixels) {
        self.size = pixels.size
        storage = UnsafeMutablePointer<UInt8>.allocate(capacity: size)
        storage.initialize(from: pixels.storage, count: pixels.size)
    }
    
    subscript(offset: Int) -> UInt8 {
        get {
            return storage[offset]
        }
        set {
            storage[offset] = newValue
        }
    }
    
    deinit {
        storage.deallocate(capacity: size)
    }
}

struct Image {
    private (set) var width: Int
    private (set) var height: Int
    private var pixels: Pixels
    private var mutatingPixels: Pixels {
        mutating get {
            if isKnownUniquelyReferenced(&pixels) {
                return pixels
            } else {
                pixels = Pixels(pixels: pixels)
                return pixels
            }
            
        }
    }
    init(width: Int, height: Int, value: UInt8) {
        self.width = width
        self.height = height
        self.pixels = Pixels(size: width * height, value: value)
    }
    subscript(x: Int, y: Int) -> UInt8 {
        get {
            return pixels[y * width + x]
        }
        set {
            mutatingPixels[y * width + x] = newValue
        }
    }
    mutating func clear(with value: UInt8) {
        mutatingPixels.storage.initialize(from: repeatElement(value, count: width * height))
    }
}


var image1 = Image(width: 4, height: 4, value: 0)
image1[0,0]
image1[0,0] = 100
image1[0,0]
image1[1,1]

var image2 = image1
image2[0,0]
image1[0,0] = 2
image1[0,0]
image2[0,0]

var image3 = image2
image3.clear(with: 255)
image3[0,0]
image2[0,0]


