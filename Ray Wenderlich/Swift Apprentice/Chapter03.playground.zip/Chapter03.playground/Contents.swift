//: Playground - noun: a place where people can play

import Cocoa

/*
 Mini exercises page 55 - Type Conversion
 1. Create a constant called age1 and set it equal to 42.Create a constant called age2 and set it equal to 21. Check using Option-click that the type for both has been inferred correctly as Int.
 2. Create a constant called avg1 and set it equal to the average of age1 and age2 using the naïve operation (age1 + age2) / 2. Use Option-click to check the type and check the result of avg1. Why is it wrong?
 3. Correct the mistake in the above exercise by casting age1 and age2 to Double in the formula. Use Option-click to check the type and check the result of avg1. Why is it now correct?
*/
let age1 = 42
let age2 = 21
let avg1 = (age1 + age2) / 2
let avg1Corrected = (Double(age1) + Double(age2)) / 2

/*
 Mini exercises page 60 - Strings
 1. Create a string constant called firstName and initialize it to your firstname. Also create a string constant called lastName and initialize it to your last name.
 2. Create a string constant called fullName by adding the firstName and lastName constants to gether, separated by a space.
 3. Using interpolation, create a string constant called myDetails that uses the fullName constant to create a string introducing yourself. For example, my string would read: "Hello, my name is Matt Galloway.".
*/
let firstName = "Arthur"
let lastName = "Dead"
let fullName = firstName + " " + lastName
let myDetails = "Hello, my name is \(fullName)"

/* Mini exercises page 62 - Tuples
 1. Declare a constant tuple that contains three Int values followed by a Double. Use this to represent a date (month, day, year) followed by an average temperature for that date.
 2. Change the tuple to name the constituent components. Give them names related to the data that they contain: month, day, year and averageTemperature.
 3. In one line,read the day and average temperature values into two constants. You’ll need to employ the underscore to ignore the month and year.
 4. Up until now, you’ve only seen constant tuples. But you can create variable tuples, too. Change the tuple you created in the exercises above to a variable by using var instead of let. Now change the average temperature to a new value.
*/
let tuple1 = (21, 6, 2017, 20.5)
let tuple2 = (day: 21, month: 6, year: 2017, temperature: 20.5)
let (day, _, _, temperature) = tuple2
var tuple3 = tuple2
tuple3.temperature = 21.5
tuple3

/* CHALLENGES (page 65) */

/* 1. Create a constant called coordinates and assign a tuple containing two and three to it.*/
let coordinates = (2, 3)

/* 2. Create a constant called namedCoordinate with a row and column component */
let namedCoordinate = (row: 0, column: 0)

/* 3. Which of the following are valid statements? :
 let character: Character = "Dog" - N
 let character: Character = "! "  - Y
 let string: String = "Dog" - Y
 let string: String = "! " - N
 */
//let character: Character = "Dog"
let character: Character = "🐶"
let string: String = "Dog"
// let string: String = "🐶"

/* 4. Is this valid code? 
 let tuple = (day: 15, month: 8, year: 2015)
 let day = tuple.Day 
 */
let tuple = (day1: 15, month: 8, year: 2015)
let day1 = tuple.day1

/* 5. What is wrong with the following code? 
 let name = "Matt"
 name += " Galloway"
 */
var name = "Matt"
name += " Galloway"

/* 6. What is the type of the constant called value?
 let tuple = (100, 1.5, 10)
 let value = tuple.1 
 */
// (Should be Double)
let tuple6 = (100, 1.5, 10)
let value = tuple6.1

/* 7. What is tha value of the constant called month? 
 let tuple = (day: 15, month: 8, year: 2015)
 let month = tuple.month
 */
// (Should be 8)
let tuple7 = (day: 15, month: 8, year: 2015)
let month = tuple7.month

/* 8. What is the value of the constant called summary?
 let number = 10
 let multiplier = 5
 let summary = "\(number) multiplied by \(multiplier) equals \(number * multiplier)"
 */
// (Should be "10 multiplied by 5 equals 50")
let number = 10
let multiplier = 5
let summary = "\(number) multiplied by \(multiplier) equals \(number * multiplier)"

 /* 9. What is the sum of a, b minus c? 
 let a = 4
 let b: Int32 = 100
 let c: UInt8 = 12
 */
// Should be 92
let a = 4
let b: Int32 = 100
let c: UInt8 = 12
let sum = a + Int(b) - Int(c)

/* 10. What is the arithmetic difference between Double.pi and Float.pi? */
// Float < Double
let difference = Double.pi - Double(Float.pi)


