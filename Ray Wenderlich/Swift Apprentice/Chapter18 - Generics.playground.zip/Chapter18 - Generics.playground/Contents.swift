import Cocoa

// Values defined by other values
enum PetKind {
    case cat
    case dog
}

struct KeeperKind {
    var keeperOf: PetKind
}

let catKeeper = KeeperKind(keeperOf: .cat)
let dogKeeper = KeeperKind(keeperOf: .dog)

// Types defined by other types
class Cat {
    var name: String
    init(name: String){
        self.name = name
    }
}
class Dog {
    var name: String
    init(name: String){
        self.name = name
    }
}
class Keeper<Animal: Pet> {
    var name: String
    var morningCare: Animal
    var afternoonCare: Animal
    
    init(name: String, morningCare: Animal, afternoonCare: Animal){
        self.name = name
        self.morningCare = morningCare
        self.afternoonCare = afternoonCare
    }
}

let jason = Keeper(name: "Jason", morningCare: Cat(name: "Whiskers"), afternoonCare: Cat(name: "Sleepy"))

/* Mini exercises page 271 - Using type parameters 
 Try instantiating another Keeper, but this time for dogs.
 What do you think would happen if you tried to instantiate a Keeper with a dog in
 the morning and a cat in the afternoon?
 What happens if you try to instantiate a Keeper, but for strings?
 */
let erik = Keeper(name: "Erik", morningCare: Dog(name: "Snoopy"), afternoonCare: Dog(name: "Ulvy"))

// let ida = Keeper(name: "Ida", morningCare: Dog(name: "Morgan"), afternoonCare: Cat(name: "Princess"))
// cannot convert value of type 'Cat' to expected argument type 'Dog'

// let kristin = Keeper(name: "Ida", morningCare: String(name: "A String"), afternoonCare: String(name: "Another string"))
// argument labels '(name:)' do not match any available overloads

// Type constraints 
protocol Pet {
    var name: String { get }
}
extension Cat: Pet {}
extension Dog: Pet {}

let cats = ["Miss Gray", "Whiskers"].map { Cat(name: $0) }
let dogs = ["Sparky", "Rusty", "Astro"].map { Dog(name: $0) }
let pets : [Pet] = [ Cat(name: "Mittens"), Dog(name: "Yeller")]
// Arrays of type Pet that can mix Dog and Cat elements together
func herd(_ pets: [Pet]) {
    pets.forEach {
        print("Come \($0.name)!")
    }
}
// Arrays of any kind of Pet (but of a single type)
func herd<Animal: Pet>(_ pets: [Animal]) {
    pets.forEach {
        print("Here \($0.name)!")
    }
}
// Only cats
func herd<Animal: Cat>(_ cats: [Animal]) {
    cats.forEach {
        print("Here kitty, kitty. Here \($0.name)!")
    }
}
// Only dogs
func herd<Animal: Dog>(_ dogs: [Animal]) {
    dogs.forEach {
        print("Here \($0.name)! Come here!")
    }
}
herd(dogs)
herd(cats)
herd(pets)

extension Array where Element: Cat {
    func meow() {
        forEach {
            print("\($0.name) says meow!")
        }
    }
}
cats.meow()

// Arrays 
let animalAges: Array<Int> = [2, 5, 7, 9]

// Dictionaries
let intNames: Dictionary<Int, String> = [42: "forty-two"]

// Optionals
enum OptionalString {
    case none
    case some(String)
}
enum OptionalDate {
    case none
    case some(Date)
}
struct FormResults {
    var birthday: OptionalDate
    var lastName: OptionalString
}

// Generic function parameters
func swapped<T, U> (_ x: T, _ y: U) -> (U, T) {
    return (y, x)
}
print(swapped(33, "Jay"))

/* CHALLENGES page 278 */

/* A: Building a collection 
 Consider the pet and keeper example from earlier in the chapter: 
 class Cat {
 var name: String
 init(name: String) {
 self.name = name
 }
 }
 class Dog {
 var name: String
 init(name: String) {
 self.name = name
 }
 }
 class Keeper<Animal> {
 var name: String
 var morningCare: Animal
 var afternoonCare: Animal
 init(name: String, morningCare: Animal, afternoonCare: Animal) {
 self.name = name
 self.morningCare = morningCare
 self.afternoonCare = afternoonCare
 } }
 Imagine that instead of looking after only two animals, every keeper looks after a 
    changing number of animals throughout the day. It could be one, two, ten animals 
    per keeper instead of just morning and afternoon ones.
 You’d have to do things like the following:
 let christine = Keeper<Cat>(name: "Christine")
 christine.lookAfter(someCat)
 christine.lookAfter(anotherCat)
 You’d want to be able to access the count of all of animals for a keeper like 
    christine.countAnimals and to access the 51st animal via a zero-based index 
    like christine.animalAtIndex(50).
 Of course, you’re describing your old friend the array type, Array<Element>!
 Your challenge is to update the Keeper type to have this kind of interface. 
    You’ll probably want to include a private array inside Keeper and then provide methods 
    and properties on Keeper to allow outside access to the array.
 */
print("\nChallenge A:")
class Catt {
    var name: String
    init(name: String) {
        self.name = name
    }
}
class Dogg {
    var name: String
    init(name: String) {
        self.name = name
    }
}
class Keeperr<Animal> {
    var name: String
    var morningCare: Animal?
    var afternoonCare: Animal?
    
    private var animals: [Animal] = []
    var animalsCount: Int {
        return animals.count
    }
    init(name: String) {
        self.name = name
    }
    init(name: String, morningCare: Animal, afternoonCare: Animal) {
        self.name = name
        self.morningCare = morningCare
        self.afternoonCare = afternoonCare
    }
    
    func lookAfter(_ animal: Animal) {
        animals.append(animal)
    }
    func animal(at index: Int) -> Animal {
        return animals[index]
    }
    
}
let christine = Keeperr<Catt>(name: "Christine")
let droopy = Catt(name: "Droopy")
let grumpy = Catt(name: "Grumpy")
christine.lookAfter(droopy)
christine.lookAfter(grumpy)
print("Christine takes care of \(christine.animalsCount) catts:")
for i in 0..<christine.animalsCount {
    print(christine.animal(at: i).name)
}




