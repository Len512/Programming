import Cocoa

// Stored properties

struct Contact {
    var fullName: String
    var emailAddress: String
}

var person = Contact(fullName: "Grace Murray", emailAddress: "grace@navy.mil")

let name = person.fullName
let email = person.emailAddress

person.fullName = "Grace Hopper"
let grace = person.fullName

// Computed properties

struct TV {
    var height: Double
    var width: Double
    
    var diagonal: Int {
        get {
            let result = sqrt(height * height + width * width)
            let roundedResult = result.rounded(.toNearestOrAwayFromZero)
            return Int(roundedResult)
        }
        set {
            let ratioWidth = 16.0
            let ratioHeight = 9.0
            height = Double(newValue) * ratioHeight / sqrt(ratioWidth * ratioWidth + ratioHeight * ratioHeight)
            width = height * ratioWidth / ratioHeight
        }
    }
    var diagonalInInches: Int {
        let diag = Double(diagonal) * 0.0393701
        let inches = diag.rounded()
        return Int(inches)
    }
}
var tv = TV(height: 53.93, width: 95.87)
let size = tv.diagonal
tv.width = tv.height
let diagonal = tv.diagonal

/* Mini exercise page 177 - Do you have a television or a computer monitor? Measure the height and width, 
    plug it into a TV struct, and see if the diagonal measurement matches what you think it is. */

var screen = TV(height: 1055, width: 440)
let resolution = screen.diagonalInInches

tv.diagonal = 70
let height = tv.height
let width = tv.width

// Type properties

struct Level {
    let id: Int
    var boss: String
    var unlocked: Bool {
        // property observer, when the player unlocks a new level, 
        // it will update the highestLevel type property
        didSet {
            if unlocked && id > Level.highestLevel {
                Level.highestLevel = id
            }
        }
    }
    static var highestLevel = 1
}
let level1 = Level(id: 1, boss: "Chameleon", unlocked: true)
let level2 = Level(id: 2, boss: "Squid", unlocked: false)
let level3 = Level(id: 3, boss: "Chupacabra", unlocked: false)
let level4 = Level(id: 4, boss: "Yeti", unlocked: false)

// Use property observers to limit the value of a variable 
struct LightBulb {
    static let maxCurrent = 40
    var current = 0 {
        didSet {
            if current > LightBulb.maxCurrent {
                print("LightBulb: Current too high, falling back to previous setting")
                current = oldValue
            }
        }
    }
}

var light = LightBulb()
light.current = 50
var current = light.current
light.current = 40
current = light.current

/* Mini exercise page 182: Setters and getters
 In the lightbulb example, the bulb goes back to a successful setting if the current gets too high.
    In real life, that wouldn’t work. The bulb would burn out! Rewrite the structure so that the bulb 
    turns off before the current burns it out. You’ll need to use the willSet observer for this. 
    This observer gets called before the value is changed. The value that is about to be set is available 
    in the constant newValue. Keep in mind that you cannot change this newValue, and it will still be set, 
    so you’ll have to do more than just add a willSet observer. :]*/

struct MyLightBulb {
    static let maxCurrent = 40
    var isOn: Bool = false
    var current = 30 {
        willSet {
            if newValue > MyLightBulb.maxCurrent {
                print("Current too high, turning off the light.")
                isOn = false
            }
        }
        didSet {
            if current > MyLightBulb.maxCurrent {
                print("Current too high, falling back to previous setting")
                current = oldValue
            }
        }
    }
}

var light1 = MyLightBulb()
light1.isOn = true
var current1 = light1.current
light1.current = 20
current = light1.current
light1.current = 50
current = light1.current
print("Is light switch on? \(light1.isOn) ")
light1.isOn = true
print("Is light switch on? \(light1.isOn) ")

// Lazy properties 

struct Circle1 {
    lazy var pi = {
        return ((4.0 * atan(1.0 / 5.0)) - atan(1.0 / 239.0)) * 4.0
    }()
    var radius = 0.0
    var circumference: Double {
        mutating get {
            return pi * radius * 2
        }
    }
    init (radius: Double) {
        self.radius = radius
    }
}

var circle = Circle1(radius: 5)
let circumference = circle.circumference

/* Mini exercise page 183 - Lazy properties 
 Given the Circle example above, remove the lazy stored property pi. Use the value of pi from the Swift standard library instead.
 */

struct Circle {
    let pi = Double.pi
    var radius = 0.0
    var circumference: Double {
        mutating get {
            return pi * radius * 2
        }
    }
    init(radius: Double) {
        self.radius = radius
    }
}
var circle1 = Circle(radius: 10)
let circum1 = circle1.circumference


/* CHALLENGES page 184 */

/* Set A: We all scream for ice cream 
 Rewrite the IceCream structure below to use default values and lazy initialization: 
 struct IceCream {
 let name: String
 let ingredients: [String]
 }
 1. Change the values in the initializer to default values for the properties.
 2. Lazily initialize the ingredients array
 */
struct IceCream {
    var name = "Simple Ice Cream"
    lazy var ingredients : [String] = {
        return ["milk", "sugar", "egg yolks"]
    }()
    init(name: String) {
        self.name = name
    }
}

var iceCream = IceCream(name: "Vanilla")
print(iceCream.ingredients)
iceCream.ingredients.append("vanilla")
print(iceCream.ingredients)

/* Set B: At the beginning of the chapter, you saw a Car structure. You’ll dive into the inner workings 
    of that car now. Rewrite the FuelTank structure below with property observer functionality: 
 struct FuelTank {
 var level: Double // decimal percentage between 0 and 1
 }
 1. Add a lowFuel stored property of Boolean type to the structure
 2. Flip the lowFuel Boolean when the level drops below 10%
 3. Ensure that when the tank fills back up, the lowFuel warning will turn off
 4. Set the level to a minimum of 0 or a maximum of 1 if it gets set above or below the expected values
 */
struct Car {
    let make: String
    let colour: String
    var tank: FuelTank
    func describe() {
        print("The car is a \(colour) \(make). The fuel tank level is \(tank.level). Low fuel is set to \(tank.lowFuel)")
    }
}
struct FuelTank {
    static let maximumLevel = 1.0
    static let minimumLevel = 0.0
    var lowFuel: Bool = false
    // Decimal percentage between 0 and 1
    var level = 1.0 {
        didSet {
            if level < 0.1 {
                print("Fuel tank is almost empty!")
                lowFuel = true
            } else {
                lowFuel = false
            }
            if level < 0.0 {
                level = 0.0
            }
            if level > 1.0 {
                level = 1.0
            }
        }
    }
}
var car = Car(make: "Toyota", colour: "Red", tank: FuelTank(lowFuel: false, level: 0.8))
car.describe()
car.tank.level = 0.05
car.describe()
car.tank.level = -5
car.describe()
car.tank.level = 5
car.describe()

