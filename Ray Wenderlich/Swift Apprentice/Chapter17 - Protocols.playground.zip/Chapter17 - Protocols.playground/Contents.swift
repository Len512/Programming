import Cocoa

// Introducing protocols

protocol Vehicle {
    func accelerate()
    func stop()
}
class Unicycle: Vehicle {
    var peddling = false
    
    func accelerate() {
        peddling = true
    }
    func stop() {
        peddling = false
    }
}
enum Direction {
    case left
    case right
}

protocol DirectionalVehicle {
    func accelerate()
    func stop()
    func turn(direction: Direction)
    func description() -> String
}
protocol OptionalDirectionVehicle {
    func turn()
    func turn(direction: Direction)
}
protocol VehicleProperties {
    var weight: Int { get }
    var name: String { get set }
}

// Initialisers in protocols
protocol Account {
    var value: Double { get set }
    init(initialAmount: Double)
    init?(transferAccount: Account)
}
class BitcoinAccount: Account {
    var value: Double
    required init(initialAmount: Double) {
        value = initialAmount
    }
    required init?(transferAccount: Account) {
        guard transferAccount.value > 0.0 else {
            return nil
        }
        value = transferAccount.value
    }
}
var accountType: Account.Type = BitcoinAccount.self
let account = accountType.init(initialAmount: 30.0)
let transferAccount = accountType.init(transferAccount: account)!

// Protocol inheritence 

protocol WheeledVehicle: Vehicle {
    var numberOfWheels: Int { get }
    var wheelSize: Double { get set }
}

/* Mini exercises page 253 - Protocols introduction
 1. Create a protocol Area that defines a read-only property area of type Double.
 2. Implement Area with structs representing Square, Triangle, and Circle.
 3. Add a circle, square, and triangle to an array. Convert the array of shapes to an array of areas using map.
 */

protocol Area {
    var area: Double { get }
    var description: String { get }
}
struct Square: Area {
    var side: Double
    var area: Double {
        return side * side
    }
    var description: String {
        return "Square with side \(side)"
    }
}
struct Triangle: Area {
    var sideA: Double
    var sideB: Double
    var sideC: Double
    var area: Double {
        let s = (sideA + sideB + sideC) / 2.0
        return sqrt(s * (s - sideA) * (s - sideB) * (s - sideC))
    }
    var description: String {
        return "Triangle with sides \(sideA), \(sideB), \(sideC)"
    }
}
struct Circle: Area {
    var radius: Double
    var area: Double {
        return Double.pi * radius * radius
    }
    var description: String {
        return "Circle with radius \(radius)"
    }
}
let circle = Circle(radius: 3)
let square = Square(side: 5)
let triangle = Triangle(sideA: 2, sideB: 3, sideC: 4)
let arrayOfShapes: [Area] = [circle, square, triangle]
let arrayOfAreas = arrayOfShapes.map{
    $0.area
}
print("Array of shapes: ")
for shape in arrayOfShapes {
    print(shape.description)
}
print("Array of areas: ")
for area in arrayOfAreas {
    print(area)
}

// Implementing protocols

class Bike1: Vehicle {
    
    var peddling = false
    var brakesApplied = false
    func accelerate() {
        peddling = true
        brakesApplied = false
    }
    func stop() {
        peddling = false
        brakesApplied = true
    }
}
class Bike2: WheeledVehicle {
    let numberOfWheels = 2
    var wheelSize = 16.0
    
    var peddling = false
    var brakesApplied = false
    
    func accelerate() {
        peddling = true
        brakesApplied = false
    }
    func stop() {
        peddling = false
        brakesApplied = true
    }
}

// Associated types in protocols

protocol WeightCalculatable {
    associatedtype WeightType
    func calculateWeight() -> WeightType
}

class HeavyThing : WeightCalculatable {
    typealias WeightType = Int
    func calculateWeight() -> Int {
        return 100
    }
}
class LightThing: WeightCalculatable {
    typealias WeightType = Double
    func calculateWeight() -> Double {
        return 0.0025
    }
}

// Implementing multiple protocols
protocol Wheeled {
    var numberOfWheels: Int { get }
    var wheelSize: Double { get set }
}

class Bike: Vehicle, Wheeled {
    var peddling = false
    var brakesApplied = false
    let numberOfWheels: Int = 2
    var wheelSize: Double = 15.0
    let ID: UInt32
    
    func accelerate() {
        peddling = true
        brakesApplied = false
    }
    func stop() {
        peddling = false
        brakesApplied = true
    }
    init(wheelSize: Double){
        self.wheelSize = wheelSize
        ID = arc4random_uniform(10000)
    }
}

// Extensions and protocol conformance 
protocol Reflective {
    var typeName: String { get }
}
extension String: Reflective {
    var typeName: String {
        return "I'm a String"
    }
}
let title = "Swift Apprentice"
print(title.typeName)

class AnotherBike {
    var peddling = false
    var wheelSize = 16.0
}
extension AnotherBike: Wheeled {
    var numberOfWheels: Int {
        return 2
    }
}
extension AnotherBike: Vehicle {
    func accelerate() {
        peddling = true
    }
    func stop() {
        peddling = false
    }
}

// Requiring reference semantics
protocol Named {
    var name: String { get set }
}

class ClassyName: Named {
    var name: String
    init(name: String) {
        self.name = name
    }
}
struct StructyName: Named {
    var name: String
}
var named : Named = ClassyName(name: "Classy")
var copy = named
named.name = "Still Classy"
print(named.name)
print(copy.name)

named = StructyName(name: "Structy")
copy = named

named.name = "Still Structy"
print(named.name)
print(copy.name)

// Protocols in the standard library
// Equatable
struct Record {
    var wins: Int
    var losses: Int
}

let recordA = Record(wins: 10, losses: 5)
let recordB = Record(wins: 10, losses: 5)

extension Record : Equatable {
    static func == (lhs: Record, rhs: Record) -> Bool {
        return lhs.wins == rhs.wins && lhs.losses == rhs.losses
    }
}
print(recordA == recordB)

// Comparable
extension Record: Comparable {
    static func < (lhs: Record, rhs: Record) -> Bool {
        if lhs.wins == rhs.wins {
            return lhs.losses > rhs.losses
        }
        return lhs.wins < rhs.wins
    }
}
// Free functions
let teamA = Record(wins: 14, losses: 11)
let teamB = Record(wins: 23, losses: 8)
let teamC = Record(wins: 23, losses: 9)

var leagueRecords = [teamA, teamB, teamC]

leagueRecords.sort()
leagueRecords.max()
leagueRecords.min()
leagueRecords.starts(with: [teamA, teamC])
leagueRecords.contains(teamA)

// Other useful protocols
class Student {
    let email: String
    let firstName: String
    let lastName: String
    
    init(email: String, firstName: String, lastName: String) {
        self.email = email
        self.firstName = firstName
        self.lastName = lastName
    }
}
extension Student: Equatable {
    static func ==(lhs: Student, rhs: Student) -> Bool {
        return lhs.email == rhs.email
    }
}
extension Student: Hashable {
    var hashValue : Int {
        return email.hashValue
    }
}
let john = Student(email: "johnny.appleseed@apple.com", firstName: "Johnny", lastName: "Appleseed")
let lockerMap = [john: "14B"]

// CustomStringConvertible
print(john)

extension Student: CustomStringConvertible {
    var description: String {
        return "\(firstName) \(lastName)"
    }
}
print(john)

/* CHALLENGES page 264 */

/* A: Bike protocols 
 Implement Comparable and Hashable on the Bike class. Create a Set of bikes of 
    various wheel numbers and sizes, then sort them by their wheel size.
 Note: You may simply use wheelSize to calculate hashValue. If you’d like, 
    add another property of your choice to Bike that can make it even more unique.
 */
print("\nChallenge A: ")
extension Bike: Equatable {
    static func == (lhs: Bike, rhs: Bike) -> Bool {
        return lhs.wheelSize == rhs.wheelSize && lhs.ID == rhs.ID
    }
}
extension Bike: Comparable {
    static func < (lhs: Bike, rhs: Bike) -> Bool {
        if lhs.wheelSize == rhs.wheelSize {
            return lhs.ID < rhs.ID
        }
        return lhs.wheelSize < rhs.wheelSize
    }
}
extension Bike: Hashable {
    var hashValue: Int {
        return ID.hashValue * Int(wheelSize) * (10000 + numberOfWheels)
    }
}

let bike1 = Bike(wheelSize: 15.0)
let bike2 = Bike(wheelSize: 16.0)
let bike3 = Bike(wheelSize: 16.0)

var bikes: [Bike] = [bike1, bike2, bike3]
bike1 == bike2
bike2 == bike3
bike1 < bike2
print(bike2.ID, bike3.ID)
bike2 < bike3


/* B: Pet Shop Tasks 
 Create a collection of protocols for tasks that need doing at a pet shop. 
    The pet shop has dogs, cats, fish and birds. The pet shop duties can be broken down into these tasks:
 
 All pets need to be fed.
 Pets that can fly need to be caged.
 Pets that can swim need a tank.
 Pets that walk need exercise.
 Tanks and cages need to occasionally be cleaned.
 
 1. Create classes or structs for each animal and adopt the appropriate protocols. Feel free to simply use a print() statement for the method implementations.
 2. Create homogenous arrays for animals that need to be fed, caged, cleaned, walked, and tanked. Add the appropriate animals to these arrays. The arrays should be declared using the protocol as the element type, for example var caged: [Cageable]
 3. Write a loop that will perform the proper tasks (such as feed, cage, walk) on each element of each array.
 */
print("\nChallenge B: ")
protocol Feedable {
    func feed()
}
protocol Cageable : Cleanable {
    func cage()
}
protocol Tankable : Cleanable {
    func tank()
}
protocol Walkable {
    func walk()
}
protocol Cleanable {
    func clean()
}
class Dog: Feedable, Walkable {
    func feed() {
        print("Feeding the dog...")
    }
    func walk() {
        print("Walking the dog...")
    }
}
class Cat: Feedable, Walkable {
    func feed() {
        print("Feeding the cat...")
    }
    func walk() {
        print("Walking the cat...?")
    }
}
class Fish: Feedable, Tankable {
    func feed() {
        print("Feeding the fish...")
    }
    func tank() {
        print("Putting the fish in a tank")
    }
    func clean() {
        print("Cleaning the fish tank...")
    }
}
class Bird: Feedable, Cageable {
    func feed() {
        print("Feeding the bird...")
    }
    func cage() {
        print("Putting the bird in a cage")
    }
    func clean() {
        print("Cleaning the bird cage...")
    }
}
let dog = Dog()
let cat = Cat()
let fish = Fish()
let bird = Bird()

let feeding: [Feedable] = [dog, cat, fish, bird]
let caging: [Cageable] = [bird]
let cleaning: [Cleanable] = [fish, bird]
let walking: [Walkable] = [dog, cat]
let tanking: [Tankable] = [fish]

for animal in feeding {
    animal.feed()
}
for animal in caging {
    animal.cage()
}
for animal in cleaning {
    animal.clean()
}
for animal in walking {
    animal.walk()
}
for animal in tanking {
    animal.tank()
}
