import Cocoa

// Your first enumeration

enum Month1 { case january, february, march, april, may, june, july, august,
    september, october, november, december
}

func semester (for month: Month1) -> String {
    switch month {
    case .august, .september, .october, .november, .december:
        return "Autumn"
    case .january, .february, .march, .april, .may:
        return "Spring"
    case .june, .july:
        return "Summer!!!"
    }
}

var month1 = Month1.april
semester(for: month1)

month1 = .september
semester(for: month1)

/* Mini exercise page 237  
 Wouldn't it be nice to request the semester from an instance like, `month.semester` 
    instead of using the function? Add a `semester` computed property to the `Month` enumeration.
 */
enum Month2 {
    
    case january, february, march, april, may, june, july, august, september, october, november, december

    var semester: String {
        switch self {
            case .august, .september, .october, .november, .december:
                return "Autumn"
            case .january, .february, .march, .april, .may:
                return "Spring"
            case .june, .july:
                return "Summer!!!"
        }
    }
}
var month2 = Month2.april
let semester2 = month2.semester


// Raw values 

enum Month3: Int {
    
    case january = 1, february, march, april, may, june, july, august, september, october, november, december
    
}

func monthsUntilWinterBreak(from month: Month3) -> Int {
    return Month3.december.rawValue - month.rawValue
}
monthsUntilWinterBreak(from: .april)

let fifthMonth1 = Month3(rawValue: 5)!
monthsUntilWinterBreak(from: fifthMonth1)

/* Mini exercise page 239 - Initialising with the raw value 
  Make `monthsUntilWinterBreak` a computed property of the `Month` enumeration, 
    so that you can execute the following code: 
    let monthsLeft = fifthMonth.monthsUntilWinterBreak // 7
 */
enum Month4: Int {
    case january = 1, february, march, april, may, june, july, august, september, october, november, december
    var monthsUntilWinterBreak: Int {
        return Month4.december.rawValue - self.rawValue
    }
}
let fifthMonth = Month4(rawValue: 5)!
let monthsLeft = fifthMonth.monthsUntilWinterBreak

// String raw values

enum Icon: String {
    case music
    case sports
    case weather
    var filename: String {
        return "\(rawValue.capitalized).png"
    }
}
let icon = Icon.weather
icon.filename

// Unordered raw values
enum Coin: Int {
    case penny = 1
    case nickel = 5
    case dime = 10
    case quarter = 25
}
let coin = Coin.quarter
coin.rawValue

/* Mini exercise page 241 - Raw values 
 Create an array called `coinPurse` that contains coins. 
 Add an assortment of pennies, nickels, dimes and quarters to it.
 */
var coinPurse : [Coin] = [.penny, .nickel, .nickel, .dime, .dime, .quarter]
coinPurse.append(.penny)

// Associated values 
var balance = 100

enum WithdrawalResult {
    case success(newBalance: Int)
    case error(message: String)
}

func withdraw(amount: Int) -> WithdrawalResult {
    if amount <= balance {
        balance -= amount
        return .success(newBalance: balance)
    } else {
        return .error(message: "Not enough money!")
    }
}

let result = withdraw(amount: 99)
switch result {
case .success(let newBalance):
    print("Your new balance is: \(newBalance)")
case .error(let message):
    print(message)
}

// Enumeration as state machine

enum TrafficLight {
    case red, yellow, green
}
let trafficLight = TrafficLight.red

/* Mini exercise page 243 - State machine 
 A household light switch is another example of a state machine. 
 Create an enumeration for a light that can switch `.on` and `.off`.
 */
enum HouseholdSwitch {
    case on, off
}
let householdSwitch = HouseholdSwitch.on

/* Mini exercise page 244 - Case-less enumerations 
 Euler’s number is useful in calculations for statistical bell curves and 
 compound growth rates. Add the constant e, 2.7183, to your Math namespace. 
 Then you can figure out how much money you’ll have if you invest $25,000 
 at 7% continuous interest for 20 years:
 let nestegg = 25000 * pow(Math.e, 0.07 * 20) // $101,380.95
 */
enum Math {
    static func factorial(of number: Int) -> Int {
        return (1...number).reduce(1, *)
    }
    static let e = 2.7183
}
let nestegg = 25000 * pow(Math.e, 0.07 * 20)

// Optionals 
var age: Int?
age = 17
age = nil

switch age {
case .none:
    print("No value")
case .some(let value):
    print("Got a value: \(value)")
}

let optionalNil: Int? = .none
optionalNil == nil
optionalNil == .none

/* CHALLENGES page 247 */

/* A: Adding raw values 
 Taking the coin example from earlier in the chapter, begin with the following array of coins.
 
 enum Coin: Int {
 case penny = 1
 case nickel = 5
 case dime = 10
 case quarter = 25
 }
 let coinPurse: [Coin] = [.penny, .quarter, .nickel, .dime, .penny, .dime, .quarter]
 Write a function where you can pass in the array of coins, add up the value 
 and return the number of cents.
 */
print("\nChallenge A: ")
coinPurse = [.penny, .quarter, .nickel, .dime, .penny, .dime, .quarter]

func valueOfPurse(for coinPurse: [Coin]) -> Int {
    var purseValue = 0
    for coin in coinPurse {
        purseValue += coin.rawValue
    }
    return purseValue
}
let purseValue = valueOfPurse(for: coinPurse)
print("The purse contains \(purseValue) cents")

/* B: Computing with raw values 
 Taking the example from earlier in the chapter, begin with the Month enumeration:
 
 enum Month: Int {
 case january = 1, february, march, april, may, june, july,
 august, september, october, november, december
 }
 
 Write a computed property to calculate the number of months until summer.
 
 Hint: You’ll need to account for a negative value if summer has already 
    passed in the current year. To do that, imagine looping back around for the next full year.
 */
print("\nChallenge B: ")
enum Month: Int {
    case january = 1, february, march, april, may, june, july,
    august, september, october, november, december
    var monthsUntilSummer: Int {
        if self.rawValue > 5 {
            return Month.december.rawValue - self.rawValue + Month.june.rawValue - Month.january.rawValue + 1
        } else {
            return Month.june.rawValue - self.rawValue
        }
    }
}
var month = Month.october
var monthsLeftTilSummer = month.monthsUntilSummer
print("There are \(monthsLeftTilSummer) months left from \(month) until summer.")
month = Month.may
monthsLeftTilSummer = month.monthsUntilSummer
print("There are \(monthsLeftTilSummer) months left from \(month) until summer.")
/* C: Pattern matching enumeration values 
 Taking the map example from earlier in the chapter, begin with the Direction enumeration:
 
 enum Direction {
 case north
 case south
 case east
 case west
 }
 
 Imagine starting a new level in a video game. The character makes a series of movements in the game.
 Calculate the position of the character on a top-down level map:
 
 let movements: [Direction] = [.north, .north, .west, .south,
 .west, .south, .south, .east, .east, .south, .east]
 
 Hint: Use a tuple for the location:
 var location = (x: 0, y: 0)

 */

print("\nChallenge C: ")
enum Direction {
    case north
    case south
    case east
    case west
}
var location = (x: 0, y: 0)
print("Starting location: \(location)")
let movements: [Direction] = [.north, .north, .west, .south, .west, .south, .south, .east, .east, .south, .east]
for movement in movements {
    switch movement {
    case .north:
        location.y -= 1
    case .south:
        location.y += 1
    case .west:
        location.x += 1
    case .east:
        location.x -= 1
    }
}
print("Final location: \(location)")

