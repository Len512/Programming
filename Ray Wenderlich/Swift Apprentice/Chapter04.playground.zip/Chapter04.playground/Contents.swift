//: Playground - noun: a place where people can play

import Cocoa

/* Mini exercises page 76 - Comparison operators
 1. Create a constant called myAge and set it to your age.Then, create a constant called isTeenager that uses Boolean logic to determine if the age denotes someone in the age range of 13 to 19.
 2. Create another constant called theirAge and set it to myage,which is 30. Then, create a constant called bothTeenagers that uses Boolean logic to determine if both you and I are teenagers.
 3. Create a constant called reader and set it to your name as a string. Create a constant called author and set it to my name, Matt Galloway. Create a constant called authorIsReader that uses string equality to determine if reader and author are equal.
 4. Create a constant called readerBeforeAuthor which uses string comparison to determine if reader comes before author.
 */
let myAge = 36
let isTeenager = myAge >= 13 && myAge <= 13
let theirAge = 30
let bothTeenagers = isTeenager && theirAge >= 13 && theirAge <= 19
let reader = "Arthur Dead"
let author = "Matt Galloway"
let authorIsReader = reader == author
let readerBeforeAuthor = reader < author

/* Mini exercises page 77 - The if statement
 1. Create a constant called `myAge` and initialize it with your age. Write an if statement to print out Teenager if your age is between 13 and 19, and Not a teenager if your age is not between 13 and 19.
 2. Create a constant called `answer` and use a ternary condition to set it equal to the result you print out for the same cases in the above exercise. Then print out answer.
 */
let myAge1 = 36
if myAge1 >= 13 && myAge1 <= 19 {
    print("Teenager")
} else {
    print("Not a teenager")
}
let answer = (myAge1 >= 13 && myAge1 <= 19) ? "Teenager": "Not a teenager"
print(answer)

/* Mini exercises page 80 - Loops
 1. Create a variable named `counter` and set it equal to 0. Create a `while` loop with the condition `counter < 10` which prints out `counter` is `X` (where `X` is replaced with counter value) and then increments `counter` by 1.
 2. Create a variable named counter and set it equal to 0. Create another variable named roll and set it equal to 0. Create a repeat-while loop. Inside the loop, set roll equal to Int(arc4random_uniform(6)) which means to pick a random number between 0 and 5. Then increment counter by 1. Finally, print After X rolls, roll is Y where X is the value of counter and Y is the value of roll. Set the loop condition such that the loop finishes when the first 0 is rolled.
 */
var counter = 0
while counter < 10 {
    print("Counter is \(counter)")
    counter += 1
}
var counter1 = 0
var roll = 0
repeat {
    roll = Int(arc4random_uniform(6))
    counter1 += 1
    print("After \(counter1) rolls, roll is \(roll)")
} while roll != 0


/* CHALLENGES page 81 */

/* 1. What is wrong with the following code?
 let firstName = "Matt"
 if firstName == "Matt" {
 let lastName = "Galloway"
 } else if firstName == "Ray" {
 let lastName = "Wenderlich"
 }
 let fullName = firstName + " " + lastName
 */
// if firstName is neither Matt nor Ray, then the fullName will never be valid, since lastName will not be defined
let firstName = "Matt"
var lastName: String = "(Last name unknown)"
if firstName == "Matt" {
    lastName = "Galloway"
} else if firstName == "Ray" {
    lastName = "Wenderlich"
}
let fullName = firstName + " " + lastName

/* 2. In each of the following statements, what is the value of the Boolean answer constant?
 let answer = true && false
 let answer = false || false
 let answer = (true && 1 != 2) || (4 > 3 && 100 < 1)
 let answer = ((10 / 2) > 3) && ((10 % 2) == 0)
 */
// false, false, true, true
let answer1 = true && false
let answer2 = false || false
let answer3 = (true && 1 != 2) || (4 > 3 && 100 < 1)
let answer4 = ((10 / 2) > 3) && ((10 % 2) == 0)

/* 3. Suppose the squares on a chessboard are numbered left to right, top to bottom, with 0 being the top-left square and
 63 being the bottom-right square. Rows are numbered top to bottom, 0 to 7. Columns are numbered left to right, 0 to 7.
 Given a current position on the chessboard, expressed as a row and column number, calculate the next position on the
 chessboard, again expressed as a row and column number. The ordering is determined by the numbering from 0 to 63.
 The position after 63 is again 0.*/
var currentPosition = (row: Int(arc4random_uniform(8)), column: Int(arc4random_uniform(8)))
var nextPosition: (row: Int, column: Int)

if currentPosition == (7, 7) {
    nextPosition = (0, 0)
} else if currentPosition.column == 7 {
    nextPosition.row = currentPosition.row + 1
    nextPosition.column = 0
} else {
    nextPosition = (currentPosition.row, currentPosition.column + 1)
}
print("Current position \(currentPosition), next position \(nextPosition)")

/* 4. Given the coefficients a, b and c, calculate the solutions to a quadratic equation with these coefficients.
 Take into account the different number of solutions (0, 1 or 2). If you need a math refresher, this Wikipedia
 article on the quadratic equation will help https://en.wikipedia.org/wiki/Quadratic_formula
 */
let a = 1.0
let b = -2.0
let c = 1.0
let discriminant = b * b - 4 * a * c
var solution: String
if discriminant < 0 {
    solution = "The equation has no solutions"
} else {
    let x1 = (-b + sqrt(discriminant)) / (2 * a)
    let x2 = (-b - sqrt(discriminant)) / (2 * a)
    if discriminant == 0 {
        solution = "The equation has 1 solution: x = \(x1)"
    } else {
        solution = "The equation has 2 solutions: x1 = \(x1) and x2 = \(x2)"
    }
}

/* 5. Given a month (represented with a String in all lowercase) and the current year (represented with an Int),
 calculate the number of days in the month. Remember that because of leap years, "february" has 29 days when
 the year is a multiple of 4 but not a multiple of 100.  February also has 29 days when the year is a multiple of 400. */
let aMonth: String = "february"
let aYear: Int = 2020
let daysInAMonth: Int
if aMonth == "april" || aMonth == "june" || aMonth == "september" || aMonth == "november" {
    daysInAMonth = 30
} else if aMonth == "february" {
    if ((aYear % 4 == 0 && aYear % 100 != 0) || aYear % 100 == 0) {
        daysInAMonth = 29
    } else {
        daysInAMonth = 28
    }
} else {
    daysInAMonth = 31
}

/* 6. Given a number, determine if this number is a power of 2. (Hint: you can use log2(number) to find
 the base 2 logarithm of number. log2(number) will return a whole number if number is a power of two.
 You can also solve the problem using a loop and no logarithm.)*/
let aNumber: Double = 6
let log = log2(aNumber)
if log.truncatingRemainder(dividingBy: 1) == 0 {
    print("\(aNumber) is a power of 2")
} else {
    print("\(aNumber) is not a power of 2")
}

/* 7. Print a table of the first 10 powers of 2. */
var exponent = 0
var power = 1
print("Exponent\tPower")
while exponent < 10 {
    print("\(exponent)\t\t\t\(power)")
    exponent += 1
    power *= 2
}

/* 8. Given a number n, calculate the n-th Fibonacci number.  (Recall Fibonacci is 1, 1, 2, 3, 5, 8, 13, ... 
    Start with 1 and 1 and add these values together to get the next value.  The next value is the sum of the 
    previous two.  So the next value in this case is 8+13 = 21.)*/

var fib0 = 1
var fib1 = 1
var fib = 0
let n = 7
var i = 3
while i <= n {
    fib = fib0 + fib1
    i += 1
    fib0 = fib1
    fib1 = fib
}
print("The \(n)-th Fibonacci is \(fib)")

/* 9. Given a number n, calculate the factorial of n.  (Example: 4 factorial is equal to 1 * 2 * 3 * 4.) */
let nFactorial = 5
var j = 1
var factorial = 1
if nFactorial == 0 {
    factorial = 1
} else {
    while j <= nFactorial {
        factorial *= j
        j += 1
    }
}
print("\(nFactorial)! = \(factorial)")

/* 10. Given a number between 2 and 12, calculate the odds of rolling this number using two six-sided dice. 
    Compute it by exhaustively looping through all of the combinations and counting the fraction of outcomes 
    that give you that value. Don't use a formula.*/

var dice1 = 1
let target = 11
var count = 0

while dice1 <= 6 {
    var dice2 = 1
    while dice2 <= 6 {
        if dice1 + dice2 == target {
            count += 1
        }
        dice2 += 1
    }
    dice1 += 1
}

let possibilities = 36
let percentage = Int((Double(count) / 36) * 100)
print("The odds of rolling \(target) with 2 die is \(percentage)%")





