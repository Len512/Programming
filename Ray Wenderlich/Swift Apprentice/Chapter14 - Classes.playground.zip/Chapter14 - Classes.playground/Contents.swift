import Cocoa

class Person {
    var firstName: String
    var lastName: String
    
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
    }
    
    var fullName: String {
        return "\(firstName) \(lastName)"
    }
}
let john = Person(firstName: "Johnny", lastName: "Appleseed")
var homeOwner = john

john.firstName = "John"
john.firstName
homeOwner.firstName

/* Mini exercise page 203 - Reference types */
homeOwner.lastName = "Cleese"
print(homeOwner.fullName)
print(john.fullName)
// Both are changed

john.lastName = "Appleseed"

let imposterJohn = Person(firstName: "John", lastName: "Appleseed")

john === homeOwner
john === imposterJohn
imposterJohn === homeOwner

// Assignment of existing variables changes the instances the variables reference
homeOwner = imposterJohn
john === homeOwner

homeOwner = john
john === homeOwner

// Create fake imposter johns. Use === to see if any of these imposters are our real John
var imposters = (0...100).map{_ in
    Person(firstName: "John", lastName: "Appleseed")
}
// Equality == is not effective when John cannot be identified by his name alone
imposters.contains {
    $0.firstName == john.firstName && $0.lastName == john.lastName
}
// Check to ensure the real John is not among the imposters
imposters.contains {
    $0 === john
}
// Hide the real John among the imposters and check again
imposters.insert(john, at: Int(arc4random_uniform(100)))
imposters.contains {
    $0 === john
}
// SInce Person is a reference type, use === and grab the real John 
if let whereIsJohn = imposters.index(where: {$0 === john}) {
    imposters[whereIsJohn].lastName = "Bananapeel"
}
john.fullName

/* Mini exercise page 205 - Object identity 
 Write a function memberOf(person: Person, group: [Person]) -> Bool that will return true 
    if person can be found inside group, and false if it can not.
 Test it by creating two arrays of five Person objects for group and using john as the person. 
    Put john in one of the arrays, but not in the other.
 */
john.lastName = "Cleese"
func memberOf(person: Person, group: [Person]) -> Bool {
    for member in group {
        if member === person {
            return true
        }
    }
    return false
}
var group1 = (0...4).map{ _ in
    Person(firstName: "Arthur", lastName: "Dead")
}
var group2 = (0...5).map{ _ in
    Person(firstName: "John", lastName: "Cleese")
}
group1.insert(john, at: 2)

print(memberOf(person: john, group: group1))
print(memberOf(person: john, group: group2))

// Methods and mutability 
struct Grade {
    var letter: String
    var points: Double
    var credits: Double
}

class Student1 {
    var firstName: String
    var lastName: String
    var grades: [Grade] = []
    
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
    }
    
    func recordGrade( _ grade: Grade) {
        grades.append(grade)
    }
}
let jane1 = Student1(firstName: "Jane", lastName: "Appleseed")
let history1 = Grade(letter: "B", points: 9.0, credits: 3.0)
var math1 = Grade(letter: "A", points: 16.0, credits: 4.0)

jane1.recordGrade(history1)
jane1.recordGrade(math1)
let jane1Grades = jane1.grades
print(jane1Grades)

/* Mini exercise page 207 - Mutability and constants 
    Write a method on Student that returns the student’s Grade Point Average, or GPA. 
    A GPA is defined as the number of points earned divided by the number of credits taken. 
    For the example above, Jane earned (9 + 16 = 25) points while taking (3 + 4 = 7) credits, 
    making her GPA (25 / 7 = 3.57).
 */
class Student {
    var firstName: String
    var lastName: String
    var grades: [Grade] = []
    
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
    }
    
    func recordGrade( _ grade: Grade) {
        grades.append(grade)
    }
    func calculateGPA() -> Double {
        var totalPoints = 0.0
        var totalCredits = 0.0
        for grade in grades {
            totalPoints += grade.points
            totalCredits += grade.credits
        }
        return Double(round(100 * totalPoints / totalCredits) / 100)
    }
}
let jane = Student(firstName: "Jane", lastName: "Appleseed")
let history = Grade(letter: "B", points: 9.0, credits: 3.0)
var math = Grade(letter: "A", points: 16.0, credits: 4.0)

jane.recordGrade(history)
jane.recordGrade(math)
print(jane.calculateGPA())

extension Student {
    var fullName: String {
        return "\(firstName) \(lastName)"
    }
}
print(jane.fullName)

/* CHALLENGES page 212 */

/* A: Movie lists: benefits of reference types 
 Imagine you're writing a movie-viewing application in Swift. Users can create lists of movies and share those lists with other users.
 Create a User and a List class that uses reference semantics to help maintain lists between users.
 User - Has a method addList(_:) which adds the given list to a dictionary of List objects (using the name as a key), and list(forName:) -> List? which will return the List for the provided name.
 List - Contains a name and an array of movie titles. A print() method will print all the movies in the list.
 Create jane and john users and have them create and share lists. Have both jane and john modify the same list and call print() from both users. Are all the changes reflected?
 */
// With structs, users cannot share their lists, since each gets a copy and not a referemce to the same list
class User {
    var firstName: String
    var lastName: String
    var lists: [String: List] = [:]
    
    init(firstName: String, lastName: String) {
        self.firstName = firstName
        self.lastName = lastName
    }
    func addList(_ list: List) {
        lists[list.name] = list
    }
    func list(forName name: String) -> List? {
        return lists[name]
    }
}
class List {
    var name: String
    var titles: [String] = []
    
    init(name: String) {
        self.name = name
    }
    
    func printList() {
        print("List: \(name)")
        for movie in titles {
            print(movie)
        }
        print("\n\n")
    }
}

let janeC1 = User(firstName: "Jane", lastName: "Doe")
let johnC1 = User(firstName: "John", lastName: "Doe")
var list1 = List(name: "Fantasy")

list1.titles = ["Lord of the rings", "Game of thrones", "Dune", "Starwars"]

janeC1.addList(list1)
johnC1.addList(list1)

janeC1.lists["Fantasy"]?.printList()
johnC1.lists["Fantasy"]?.printList()

janeC1.lists["Fantasy"]?.titles.append("The Magician")
johnC1.lists["Fantasy"]?.titles.append("Harry Potter")

janeC1.lists["Fantasy"]?.printList()
johnC1.lists["Fantasy"]?.printList()

/* B: T-shirt store - class or struct?  
 Your challenge here is to build a set of objects to support a t-shirt store. 
 Decide if each object should be a class or a struct, and why.
 
 TShirt - Represents a shirt style you can buy. Each TShirt has a size, color, price, 
    and an optional image on the front.
 User - A registered user of the t-shirt store app. 
    A user has a name, email, and a ShoppingCart (below).
 Address - Represents a shipping address, containing 
    the name, street, city, and zip code.
 ShoppingCart - Holds a current order, which is composed of an array of TShirt 
    that the User wants to buy, as well as a method to calculate the total cost. 
    Additionally, there is an Address that represents where the order will be shipped.
 */

// Tshirts are value types, they can describe a real item but are not an item themselves. 
// The same goes for address. Users and ShoppingCarts are objects since they are unique for 
// each instance.

struct TShirt {
    var size: String = ""
    var colour: String = ""
    var price: Double = 0.0
    var image: NSImage?
}

class StoreUser {
    var firstName: String
    var lastName: String
    var email: String
    var cart = ShoppingCart()
    
    init(withName firstName: String, LastName lastName: String, andEmail email: String){
        self.firstName = firstName
        self.lastName = lastName
        self.email = email
    }
}

struct Address {
    var name: String = ""
    var street: String = ""
    var city: String = ""
    var postalCode: String = ""
}

class ShoppingCart {
    var currentOrder : [TShirt]
    var shippingAddress: Address
    
    init() {
        self.currentOrder = []
        self.shippingAddress = Address()
    }
    
    func cost() -> Double {
        var cost = 0.0
        for shirt in currentOrder {
            cost += shirt.price
        }
        return cost
    }
}

let user = StoreUser(withName: "Jane", LastName: "Doe", andEmail: "jane.doe@mail.com")
let shirt = TShirt(size: "Medium", colour: "Red", price: 15.0, image: nil)
let shirt2 = TShirt(size: "Medium", colour: "Black", price: 25.0, image: nil)
user.cart.currentOrder.append(shirt)
user.cart.currentOrder.append(shirt2)
user.cart.shippingAddress = Address(name: "Jane Doe", street: "Incognito str. 66", city: "Capital of Mars", postalCode: "WE 8909")

print(user.cart.cost())
print(user.cart.currentOrder)

