//: Playground - noun: a place where people can play

import Cocoa

var players = ["Alice", "Bob", "Cindy", "Dan"]
print(players.isEmpty)

if players.count < 2 {
    print("We need at least two players!")
} else {
    print("Let's start!")
}

var currentPlayer = players.min()
print(currentPlayer)
print(players.last)

if let currentPlayer = currentPlayer {
    print("\(currentPlayer) will start")
}

let upcomingPlayers = players[1...2]
print(upcomingPlayers)

func isEliminated(player: String) -> Bool {
    return !players.contains(player)
}
print(isEliminated(player: "Bob"))
players[1...3].contains("Bob")

players.append("Eli")
players += ["Gina"]
print(players)

players.insert("Frank", at: 5)
print(players)

var removedPlayer = players.removeLast()
print("\(removedPlayer) was removed")

removedPlayer = players.remove(at: 2)
print("\(removedPlayer) was removed")

/* Mini exercise page 133 - Modifying Arrays 
 Use index(of:) to determine the position of the element "Dan" in players.
 */
var ind = players.index(of: "Dan")
// EOF mini exercise

print(players)
players[4] = "Franklin"
print(players)

players[0...1] = ["Donna", "Craig", "Brian", "Anna"]
print(players)

players.sort()
print(players)

let scores = [2, 2, 8, 6, 1, 2, 1]
for (index, player) in players.enumerated() {
    print("\(index + 1). \(player)")
}

func sumOfAllItems(in array: [Int]) -> Int {
    var sum = 0
    for number in array {
        sum += number
    }
    return sum
}
print(sumOfAllItems(in: scores))

/* Mini exercise page 135 - Iterating through an array 
 Write a for-in loop that prints the players’ names and scores
 */
for (index, player) in players.enumerated() {
    print("\(player) scored \(scores[index])")
}
// EOF mini exercise 

/* CHALLENGES page 137 */

/* 1. Question 1.
 
 Which of the following are valid statements? 
 1. let array1 = [Int]()
 2. let array2 = []
 3. let array3: [String] = []
 
 For the next five statements, array4 has been declared as: 
 let array4 = [1, 2, 3]
 4. print(array4[0])
 5. print(array4[5])
 6. array4[1...2]
 7. array4[0] = 4
 8. array4.append(4)
 
 For the next five statements, array5 has been declared as: 
 var array5 = [1, 2, 3]
 9. array5[0] = array5[1]
 10. array5[0...1] = [4, 5]
 11. array5[0] = "Six"
 12. array5 += 6
 13. for item in array5 { print(item) }
 
 */
let array1 = [Int]()
//let array2 = []
let array3: [String] = []
let array4 = [1, 2, 3]

print(array4[0])
// print(array4[5])
array4[1...2]
// array4[0] = 4
// array4.append(4)

var array5 = [1, 2, 3]
array5[0] = array5[1]
array5[0...1] = [4, 5]
// array5[0] = "Six"
// array5 += 6
for item in array5 { print(item) }


/* 2. Write a function that removes the first occurrence of a given integer from an array of integers.
 This is the signature of the function:
 func removingOnce(item: Int, from array: [Int]) -> [Int]
*/
func removingOnce(item: Int, from array: [Int]) -> [Int] {
    var result = array
    if let index = array.index(of: item) {
        result.remove(at: index)
    }
    return result
}
array5 += [5]
print(array5)

var newArray5 = removingOnce(item: 5, from: array5)
print(newArray5)

/* 3. Write a function that removes all occurrences of a given integer from an array of integers. 
 This is the signature of the function:
 func removing(item: Int, from array: [Int]) -> [Int]
*/
func removing(item: Int, from array: [Int]) -> [Int] {
    var result = [Int]()
    for newItem in array where newItem != item {
        result.append(newItem)
    }
    return result
}
print(array5)
newArray5 = removing(item: 5, from: array5)
print(newArray5)

/* 4. Arrays have a reversed() method that returns an array holding the same elements as the original 
    array, in reverse order. Write a function that does the same thing, without using reversed(). 
    This is the signature of the function:
    func reversed(array: [Int]) -> [Int]
*/
func reversed(array: [Int]) -> [Int] {
    var reversedArray = [Int]()
    let limit = array.count - 1
    for i in 0...limit {
        reversedArray.append(array[limit - i])
    }
    return reversedArray
}
print(array5)
let reversedArray = reversed(array: array5)
print(reversedArray)

/* 5. The function below returns a random number between 0 and the given argument: 
    import Foundation
    func randomFromZero(to number: Int) -> Int {
        return Int(arc4random_uniform(UInt32(number)))
    }
    Use it to write a function that shuffles the elements of an array in random order. 
    This is the signature of the function:
    func randomized(_ array: [Int]) -> [Int]
 */

func randomFromZero(to number: Int) -> Int {
    return Int(arc4random_uniform(UInt32(number)))
}
func randomized(_ array: [Int]) -> [Int] {
    var randomisedArray = array
    for index in 0..<randomisedArray.count {
        let randIndex = randomFromZero(to: array.count)
        let temp = randomisedArray[randIndex]
        randomisedArray[randIndex] = randomisedArray[index]
        randomisedArray[index] = temp
    }
    return randomisedArray
}

print(array5)
newArray5 = randomized(array5)
print(newArray5)

/* 6. Write a function that calculates the minimum and maximum value in an array of integers. 
    Calculate these values yourself, do not use the methods min and max. Return nil if the given array is empty.
    This is the signature of the function:
    func minMax(of numbers: [Int]) -> (min: Int, max: Int)?
*/

func minMax(of numbers: [Int]) -> (min: Int, max: Int)? {
    if numbers.count == 0 {
        return nil
    } else {
        var min = Int.max
        var max = Int.min
        
        for number in numbers {
            if number >= max {
                max = number
            }
            if number <= min {
                min = number
            }
        }
        return (min, max)
    }
}
var result = minMax(of: array5)
result = minMax(of: [])


