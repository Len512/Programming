//: Playground - noun: a place where people can play

import Cocoa

// Mini exercises page 47
let myAge: Int = 36
var averageAge: Double = Double(myAge)
averageAge = (Double(myAge) + 30) / 2
let testNumber = 3
let evenOdd = testNumber % 2
var answer = 0
answer += 1
answer *= 10
answer >>= 3

// Challenges

// 1 Declare a constant exercises with value 11 and a variable exercisesSolved with value 0. Increment this variable every time you solve an exercise (including this one).
let exercises = 11
var exercisesSolved = 0
exercisesSolved += 1

// 2 Given the following code:
var age = 16
print(age)
age = 30
print(age)
// Declare age so that it compiles. Did you use var or let?
exercisesSolved += 1

// 3 Consider the following code:
let a: Int = 46
let b: Int = 10
// Work out what answer equals when you replace the final line of code above with each of these options: 
let answer1: Int = (a * 100) + b
let answer2: Int = (a * 100) + (b * 100)
let answer3: Int = (a * 100) + (b / 10)
exercisesSolved += 1

// 4 Add parentheses to the following calculation. The parentheses should show the order in which the operations are performed and should not alter the result of the calculation
5 * 3 - 4 / 2 * 2
((5 * 3) - ((4 / 2) * 2))
exercisesSolved += 1

// 5 Declare two constants a and b of type Double and assign both a value. Calculate the average of a and b and store the result in a constant named average
let a5: Double = 11.0
let b5: Double = 13.0
let average: Double = (a5 + b5) / 2.0
exercisesSolved += 1

// 6 A temperature expressed in °C can be converted to °F by multiplying by 1.8 then incrementing by 32. In this challenge, do the reverse: convert a temperature from °F to °C. Declare a constant named fahrenheit of type Double and assign it a value. Calculate the corresponding temperature in °C and store the result in a constant named celcius.
let fahrenheit: Double = 75
let celcius = (fahrenheit - 32) / 1.8
exercisesSolved += 1

// 7 Suppose the squares on a chessboard are numbered left to right,top to bottom, with 0 being the top-left square and 63 being the bottom-right square. Rows are numbered top to bottom, 0 to 7. Columns are numbered left to right, 0 to 7. Declare a constant position and assign it a value between 0 and 63. Calculate the corresponding row and column numbers and store the results in constants named row and column.
let position: Int = 13
let row = position / 8
let column = position % 8
exercisesSolved += 1

// 8 Declare constants named dividend and divisor of type Double and assign both a value. Calculate the quotient and remainder of an integer division of dividend by divisor and store the results in constants named quotient and remainder. Calculate the remainder without using the operator %.
let dividend: Double = 11
let divisor: Double = 5
let quotient = Int(dividend / divisor)
let remainder = dividend - divisor * Double(quotient)
exercisesSolved += 1

// 9 A circle is made up of 2pi radians,corresponding with 360 degrees. Declare a constant degrees of type Double and assign it an initial value. Calculate the corresponding angle in radians and store the result in a constant named radians.
let degrees: Double = 45.0
let radians = 2 * Double.pi * degrees / 360
exercisesSolved += 1

// 10 Declare four constants named x1, y1, x2 and y2 of type Double. These constants represent the 2-dimensional coordinates of two points. Calculate the distance between these two points and store the result in a constant named distance.
let x1 = 1.0
let y1 = 3.0
let x2 = 4.0
let y2 = 1.0
let sideA = x2 - x1
let sideB = y1 - y2
let distance = sqrt(sideA * sideA + sideB * sideB)
exercisesSolved += 1

// 11 Increment variable exercisesSolved a final time. Use the print function to print the percentage of exercises you managed to solve. The printed result should be a number between 0 and 1.
exercisesSolved += 1
let percentage = Double(exercisesSolved) / Double(exercises)
print("Solved \(percentage)")


