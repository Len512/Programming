import Cocoa

// Advanced error handling - PugBot

// Enumerate the directions in which the PugBot moves and the possible error types
enum Direction {
    case left, right, forward
}
enum PugBotError : Error {
    case invalidMove(found: Direction, expected: Direction)
    case endOfPath
}

class PugBot {
    let name: String
    let correctPath: [Direction]
    private var currentStepInPath = 0
    
    init(name: String, correctPath: [Direction]) {
        self.name = name
        self.correctPath = correctPath
    }
    
    func turnLeft() throws {
        guard currentStepInPath < correctPath.count else {
            throw PugBotError.endOfPath
        }
        let nextDirection = correctPath[currentStepInPath]
        guard nextDirection == .left else {
            throw PugBotError.invalidMove(found: .left, expected: nextDirection)
        }
        currentStepInPath += 1
    }
    
    func turnRight() throws {
        guard currentStepInPath < correctPath.count else {
            throw PugBotError.endOfPath
        }
        let nextDirection = correctPath[currentStepInPath]
        guard nextDirection == .right else {
            throw PugBotError.invalidMove(found: .right, expected: nextDirection)
        }
        currentStepInPath += 1
    }
    
    func moveForward() throws {
        guard currentStepInPath < correctPath.count else {
            throw PugBotError.endOfPath
        }
        let nextDirection = correctPath[currentStepInPath]
        guard nextDirection == .forward else {
            throw PugBotError.invalidMove(found: .forward, expected: nextDirection)
        }
        currentStepInPath += 1
    }
}
let pug = PugBot(name: "Pug", correctPath: [.forward, .left, .forward, .right])
func goHome() throws {
    try pug.moveForward()
    try pug.turnLeft()
    try pug.moveForward()
    try pug.turnRight()
}

func moveSafely(move:() throws -> ()) -> String {
    do {
        try move()
        return "Completed operation successfully."
    } catch PugBotError.invalidMove(let found, let expected) {
        return "The PugBot was supposed to move \(expected), but moved \(found) instead."
    } catch PugBotError.endOfPath() {
        return "The PugBot tried to move past the end of the path."
    } catch {
        return "An unknown error occured"
    }
}
moveSafely {
    try pug.moveForward()
    try pug.turnLeft()
    try pug.moveForward()
    try pug.turnRight()
    try pug.turnRight()
}

// Rethrows - Utility function to perform a certain movement or set of movements, several times in a row 
// this function leaves the error handling to the caller of the function (like goHome)
func perform(times: Int, movement: () throws -> ()) rethrows {
    for _ in 1...times {
        try movement()
    }
}

/* CHALLENGES page 339 */

/* 1: 
 CGAffineTransform is a transform type used by Core Graphics and used to scale, 
    rotate graphical elements. You can obtain an inverse transform by calling the inverted() method.
 Just like dividing by zero fails, inverting a singular transform can fail. 
    (When this happens CGAffineTransform does nothing to warn you except print a message to the console. You can do better.
 The following code that checks whether a transform can be inverted or will fail.
 
 extension CGAffineTransform {
 var isInvertable: Bool {
 return abs(a*d - b*c) > CGFloat.ulpOfOne
 }
 }
 CGAffineTransform().isInvertable  // false
 CGAffineTransform.identity.isInvertable // true
 
 Use the following code make viewing transforms easy:
 extension CGAffineTransform: CustomStringConvertible {
 public var description: String {
 return [a,b,c,d,tx,ty].reduce("") { $0 + " \($1)" }
 }
 }
 
 Write a method on CGAffineTransform called safeInverted() that returns an optional type. 
    If the transform can be inverted it returns the new transform. Otherwise it returns nil.
 Test your method with let scaleByTwo = CGAffineTransform.identity.scaledBy(x: 2, y: 2) 
    and observe the values you get back.
 
 2: 
 Use optional chaining to safely invert the transform and then invert it again. 
    (Much like taking the recipricol of the same number, you should wind up with the same number.)
 3: 
 Change your above design to throw MathError.singular error if the transform can't be inverted. 
    Call this new method checkedInverted() so it can co-exist nicely with your safeInverted() method. Test it out.
4: 
 Notice the return types of safeInverted() and checkedInverted(). How do they differ?
 */

extension CGAffineTransform {
    var isInvertable: Bool {
        return abs(a*d - b*c) > CGFloat.ulpOfOne
    }
}

CGAffineTransform().isInvertable  // false
CGAffineTransform.identity.isInvertable // true

extension CGAffineTransform: CustomStringConvertible {
    public var description: String {
        return [a,b,c,d,tx,ty].reduce("") { $0 + " \($1)" }
    }
}

extension CGAffineTransform {
    func safeInverted() -> CGAffineTransform? {
        return isInvertable ? inverted() : nil
    }
}

let scaleByTwo = CGAffineTransform.identity.scaledBy(x: 2, y: 2)
let scaleByTwoInverted = scaleByTwo.safeInverted()

let scaleByOptionalChaining = scaleByTwo.safeInverted()?.safeInverted()

enum MathError : Error {
    case singular
}

extension CGAffineTransform {
    func checkedInverted() throws -> CGAffineTransform? {
        guard isInvertable else {
            throw MathError.singular
        }
        return inverted()
    }
}
do {
    let scaleByCheckInverted = try scaleByTwo.checkedInverted()
} catch MathError.singular {
    print("Singular - Error")
}

let singular = CGAffineTransform()
do {
    let singularCheckInverted = try singular.checkedInverted()
} catch MathError.singular {
    print("Singular - Error")
}

// checkedInverted always returns a transform (otherwise throws an error)
// safeInverted returns an optional (a transform or nil)



