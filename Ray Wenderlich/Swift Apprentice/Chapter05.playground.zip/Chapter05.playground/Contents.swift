//: Playground - noun: a place where people can play

import Cocoa

/* Mini exercises page 91 - For Loops 
 1. Create a variable called range and set it equal to a range starting at 1 and ending with 10 inclusive. 
    Write a for loop which iterates over this range and prints the square of each number.
 2. Write a for loop which iterates over the same range as in the exercise above and prints the square root of each number. 
    Hint: you will need to type convert your loop variable.
 3. Above, you saw a for loop which iterated over only the even rows like so:
 var sum = 0
 for row in 0..<8 {
    if row % 2 == 0 {
        continue
    }
    for column in 0..<8 {
        sum += row * column
    }
 }
 Change this to use a where clause on the first for loop to skip even rows instead of using continue. Check that the sum is 448 as in the initial example.
 */
var range = 1...10
for num1 in range {
    var squareOfNum1 = num1 * num1
    print("The square of \(num1) is \(squareOfNum1)")
}
for num1 in range {
    var rootOfNum1 = sqrt(Double(num1))
    print("The square root of \(num1) is \(rootOfNum1)")
}

var sum = 0
for row in 0..<8 where row % 2 != 0 {
    for column in 0..<8 {
        sum += row * column
    }
}
print("The sum is \(sum)")

/* Mini exercises page 96 - Switch statements 
 1. Write a switch statement that takes an age as an integer and prints out the life stage related to that age. You can make up the life stages, or use my categorization as follows: 0-2 years, Infant; 3-12 years, Child; 13-19 years, Teenager; 20-39, Adult; 40-60, Middle aged; 61+, Elderly.
 2. Write a switch statement that takes a tuple containing a string and an integer. The string is a name, and the integer is an age. Use the same cases that you used in the previous exercise and let syntax to print out the name followed by the life stage. For example, for myself it would print out "Matt is an adult.".
*/
var lifeStage: String = ""
let currentAge = 36

switch currentAge {
case _ where currentAge >= 0 && currentAge <= 2:
    lifeStage = "Infant"
case _ where currentAge >= 3 && currentAge <= 12:
    lifeStage = "Child"
case _ where currentAge >= 13 && currentAge <= 20:
    lifeStage = "Teenager"
case _ where currentAge >= 21 && currentAge <= 45:
    lifeStage = "Adult"
case _ where currentAge >= 46 && currentAge <= 65:
    lifeStage = "Middle aged"
case _ where currentAge >= 66:
    lifeStage = "Elderly"
default:
    lifeStage = "Invalid age"
}
print("\(lifeStage)")

let person : (name: String, age: Int)
person = ("Matt", 30)

switch person {
case _ where person.age >= 0 && person.age <= 2:
    lifeStage = "an infant"
case _ where person.age >= 3 && person.age <= 12:
    lifeStage = "a child"
case _ where person.age >= 13 && person.age <= 20:
    lifeStage = "a teenager"
case _ where person.age >= 21 && person.age <= 45:
    lifeStage = "an adult"
case _ where person.age >= 46 && person.age <= 65:
    lifeStage = "a middle aged person"
case _ where person.age >= 66:
    lifeStage = "an elderly person"
default:
    lifeStage = "(Invalid age)"
}
print("\(person.name) is \(lifeStage)")


/* Challenges page 97 */

/* 1. In the following for loop:
 var sum = 0
 for i in 0...5 {
    sum += i
 }
 What will be the value of sum, and how many iterations will happen? */
// sum will be 15 after 6 iterations
var sum1 = 0
for i in 0...5 {
    sum1 += i
}
print(sum1)

/* 2. In the while loop below:
 var aLotOfAs = ""
 while aLotOfAs.characters.count < 10 {
    aLotOfAs += "a"
 }
 How many instances of the character “a” will there be in aLotOfAs? Hint: aLotOfAs.characters.count 
 will tell you how many characters there are in the string aLotOfAs. */
// Should be 10 since the loop will be called 10 times
var aLotOfAs = ""
while aLotOfAs.characters.count < 10 {
    aLotOfAs += "a"
}
print(aLotOfAs.characters.count)

/* 3. Consider the following switch statement:
 switch coordinates {
 case let (x, y, z) where x == y && y == z:
    print("x = y = z")
 case (_, _, 0):
    print("On the x/y plane")
 case (_, 0, _):
    print("On the x/z plane")
 case (0, _, _):
    print("On the y/z plane")
 default:
    print("Nothing special")
 }
 
 What will this code print when coordinates is each of the following?
 let coordinates = (1, 5, 0)
 let coordinates = (2, 2, 2)
 let coordinates = (3, 0, 1)
 let coordinates = (3, 2, 5)
 let coordinates = (0, 2, 4)
 */
// On the x/y plane , x = y = z, On the x/z plane, Nothing special, On the y/z plane

let coordinates = (0, 2, 4)

switch coordinates {
case let (x, y, z) where x == y && y == z:
    print("x = y = z")
case (_, _, 0):
    print("On the x/y plane")
case (_, 0, _):
    print("On the x/z plane")
case (0, _, _):
    print("On the y/z plane")
default:
    print("Nothing special")
}

/* 4. A closed range can never be empty. Why? */
// Because the second number is always included in the range

/* 5. Print a countdown from 10 to 0.  (Note: do not use the reversed() method, which will be introduced later.) */
for i in 0...10 {
    print(10 - i)
}

/* 6. Print 0.0, 0.1, 0.2, 0.3, 0.4, 0.5, 0.6, 0.7, 0.8, 0.9, 1.0.  (Note: do not use the stride(from:to:by:) function, which will be introduced later.) */
for i in 0...10 {
    print(Double(i) / 10.0)
}

